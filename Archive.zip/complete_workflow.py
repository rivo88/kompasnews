"""
COMPLETE WORKFLOW - VERSION 4.1
================================

Workflow lengkap: Input Data → AI Generate → Fill Template → HTML Output

UPDATED V4.1:
- Compatible dengan data_generator.py V4.1 (massive database)
- Compatible dengan google_discover_generator.py V4.1 (story elements)
- Enhanced display: show story elements
- Better error handling & logging
- Enhanced JSON backup with full metadata
- Support all 6 article types

Author: AI Assistant
"""

import os
import json
import re
from datetime import datetime
from pathlib import Path

from google_discover_generator import GoogleDiscoverContentGenerator
from template_integrator import TemplateIntegrator


class CompleteWorkflow:
    """Workflow lengkap dari input data sampai HTML jadi - V4.1"""
    
    def __init__(self, api_key=None, template_path="template.html"):
        """
        Initialize workflow
        
        Parameters:
        - api_key: Anthropic API key (optional, bisa pakai env variable)
        - template_path: Path ke template HTML Anda
        """
        self.generator = GoogleDiscoverContentGenerator(api_key)
        self.template_path = template_path
    
    def run_single(self, article_data, output_path=None, custom_placeholders=None):
        """
        Jalankan workflow untuk satu artikel
        
        Parameters:
        - article_data: Dict berisi data artikel (support V4.1 dengan story elements)
        - output_path: Path output HTML (optional, akan auto-generate dari title)
        - custom_placeholders: Dict custom placeholder untuk template
        
        Returns:
        - Dict: {
            "success": bool,
            "content": dict,
            "html": str,
            "output_path": str,
            "json_path": str,
            "metadata": dict,
            "error": str (jika gagal)
          }
        """
        
        print(f"\n{'='*70}")
        
        # Get article info untuk display
        article_type = article_data.get('article_type', 'single_player')
        game_name = article_data.get('game_name', 'Game')
        platform_name = article_data.get('platform_name', 'Platform')
        win_amount = article_data.get('win_amount', '0')
        
        # Display message sesuai article type (ENHANCED)
        display_msg = self._get_display_message(article_data, article_type, game_name)
        print(f"🚀 Generating: {display_msg}")
        print(f"   Type: {article_type}")
        print(f"   Game: {game_name}")
        print(f"   Platform: {platform_name}")
        print(f"   Win: Rp {int(win_amount):,}")
        
        # Show story elements if available (NEW in V4.1)
        self._show_story_elements(article_data)
        
        print(f"{'='*70}")
        
        # Step 1: Generate content dengan AI
        print("\n📝 Step 1: Generating content dengan AI...")
        try:
            content_data = self.generator.generate_content(**article_data)
            print(f"✅ Content generated!")
            print(f"   Title: {content_data['title']}")
            print(f"   Length: ~{len(content_data['content'])} characters")
        except Exception as e:
            print(f"❌ Error generating content: {e}")
            return {
                "success": False,
                "error": f"Content generation failed: {str(e)}",
                "article_data": article_data
            }
        
        # Step 2: Fill template
        print("\n🎨 Step 2: Filling template...")
        try:
            integrator = TemplateIntegrator(self.template_path)
            
            # Auto-generate output path jika tidak diberikan
            if output_path is None:
                # Generate filename dari TITLE (SEO-Friendly)
                slug = self._slugify(content_data['title'])
                output_path = f"output/{slug}.html"
            
            # Add default custom placeholders
            default_custom = {
                "{{DATE}}": datetime.now().strftime("%d %B %Y"),
                "{{PLATFORM}}": article_data.get('platform_name', ''),
                "{{GAME}}": article_data.get('game_name', ''),
                "{{URL}}": "",  # Will be filled by user or other process
                "{{GAMBAR}}": "https://via.placeholder.com/1200x630?text=Article+Image"  # Default
            }
            
            if custom_placeholders:
                default_custom.update(custom_placeholders)
            
            # Fill template
            filled_html = integrator.fill_template(
                content_data=content_data,
                output_path=output_path,
                custom_placeholders=default_custom
            )
            
            print(f"✅ HTML created: {output_path}")
            
        except FileNotFoundError as e:
            print(f"❌ Error: Template file not found!")
            return {
                "success": False,
                "error": f"Template not found: {str(e)}",
                "content_data": content_data,
                "article_data": article_data
            }
        except Exception as e:
            print(f"❌ Error filling template: {e}")
            return {
                "success": False, 
                "error": f"Template filling failed: {str(e)}",
                "content_data": content_data,
                "article_data": article_data
            }
        
        # Step 3: Save JSON backup (ENHANCED - include full metadata)
        json_path = str(output_path).replace('.html', '.json')
        try:
            # Build metadata
            metadata = {
                "article_type": article_type,
                "game_name": game_name,
                "platform_name": platform_name,
                "win_amount": win_amount,
                "generated_at": datetime.now().isoformat(),
                "generator_version": "4.1",
                "has_story_elements": bool(article_data.get('story_action'))
            }
            
            # Add story elements to metadata if available
            story_keys = ['story_action', 'story_discovery', 'story_twist', 
                         'story_situation', 'story_accident', 'story_observation', 'story_result']
            story_elements = {k: article_data.get(k) for k in story_keys if article_data.get(k)}
            
            if story_elements:
                metadata['story_elements'] = story_elements
            
            # Save complete data
            json_data = {
                **content_data,
                "metadata": metadata,
                "input_data": article_data
            }
            
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, ensure_ascii=False, indent=2)
            print(f"💾 JSON backup saved: {json_path}")
        except Exception as e:
            print(f"⚠️  Warning: Failed to save JSON backup: {e}")
            json_path = None
        
        print(f"{'='*70}\n")
        
        return {
            "success": True,
            "content": content_data,
            "html": filled_html,
            "output_path": output_path,
            "json_path": json_path,
            "metadata": metadata
        }
    
    def _show_story_elements(self, article_data):
        """Show story elements if available (NEW in V4.1)"""
        story_elements = []
        
        if article_data.get('story_situation'):
            story_elements.append(f"Situasi: {article_data['story_situation']}")
        if article_data.get('story_action'):
            story_elements.append(f"Action: {article_data['story_action']}")
        if article_data.get('story_discovery'):
            story_elements.append(f"Discovery: {article_data['story_discovery']}")
        if article_data.get('story_result'):
            story_elements.append(f"Result: {article_data['story_result']}")
        
        if story_elements:
            print(f"   📖 Story: {' → '.join(story_elements[:3])}")
    
    def _get_display_message(self, article_data, article_type, game_name):
        """Generate display message berdasarkan article type"""
        
        if article_type == 'single_player':
            prof = article_data.get('profession', 'Player')
            city = article_data.get('city', 'Jakarta')
            return f"{prof} {city}"
        
        elif article_type == 'single_player_name':
            name = article_data.get('player_name', 'Player')
            prof = article_data.get('profession', '')
            return f"{name} {prof}".strip()
        
        elif article_type == 'listicle':
            tips = article_data.get('tip_count', 5)
            return f"{tips} Trik {game_name}"
        
        elif article_type == 'multiple_players':
            count = article_data.get('player_count', 3)
            return f"{count} Players {game_name}"
        
        elif article_type == 'generic_player':
            term = article_data.get('generic_term', 'Pemain')
            city = article_data.get('city', 'Jakarta')
            return f"{term} {city}"
        
        elif article_type == 'transformational':
            prof = article_data.get('profession', 'Player')
            city = article_data.get('city', 'Jakarta')
            return f"{prof} {city} (Transformational)"
        
        else:
            return f"{game_name} Article"
    
    def run_batch(self, articles_list, output_dir="output/batch", custom_placeholders=None):
        """
        Jalankan workflow untuk multiple artikel sekaligus
        
        Parameters:
        - articles_list: List of dict article data (support V4.1 massive database)
        - output_dir: Directory output untuk batch
        - custom_placeholders: Dict custom placeholder (sama untuk semua artikel)
        
        Returns:
        - List of results dari setiap artikel
        """
        
        print(f"\n{'='*70}")
        print(f"🚀 BATCH GENERATION V4.1: {len(articles_list)} articles")
        print(f"{'='*70}")
        
        # Show statistics (NEW in V4.1)
        self._show_batch_statistics(articles_list)
        
        print()
        
        results = []
        success_count = 0
        
        for idx, article_data in enumerate(articles_list, 1):
            print(f"\n[{idx}/{len(articles_list)}] Processing...")
            
            # Run single workflow (filename akan auto-generate dari title)
            result = self.run_single(
                article_data=article_data,
                custom_placeholders=custom_placeholders
            )
            
            # Move file ke batch directory jika sukses
            if result.get('success'):
                import shutil
                
                try:
                    source = Path(result['output_path'])
                    if source.exists():
                        # Buat output directory
                        Path(output_dir).mkdir(parents=True, exist_ok=True)
                        
                        # Move HTML ke batch directory
                        dest = Path(output_dir) / source.name
                        shutil.move(str(source), str(dest))
                        result['output_path'] = str(dest)
                        
                        # Move JSON juga
                        if result.get('json_path'):
                            json_source = Path(result['json_path'])
                            if json_source.exists():
                                json_dest = Path(output_dir) / json_source.name
                                shutil.move(str(json_source), str(json_dest))
                                result['json_path'] = str(json_dest)
                        
                        success_count += 1
                        
                except Exception as e:
                    print(f"⚠️  Warning: Failed to move file: {e}")
            
            results.append(result)
            
            # Rate limiting - delay antar request
            if idx < len(articles_list):
                import time
                time.sleep(2)  # 2 detik delay
        
        # Summary (ENHANCED)
        self._print_batch_summary(results, success_count, output_dir, articles_list)
        
        return results
    
    def _show_batch_statistics(self, articles_list):
        """Show batch statistics (NEW in V4.1)"""
        types_count = {}
        has_story_count = 0
        
        for article in articles_list:
            atype = article.get('article_type', 'unknown')
            types_count[atype] = types_count.get(atype, 0) + 1
            
            if article.get('story_action'):
                has_story_count += 1
        
        print(f"\n📊 Batch Statistics:")
        print(f"   Total Articles: {len(articles_list)}")
        print(f"   With Story Elements: {has_story_count}/{len(articles_list)}")
        
        print(f"\n📈 Article Types:")
        for atype, count in sorted(types_count.items()):
            print(f"   - {atype}: {count}")
        
        # Estimate cost
        estimated_cost = len(articles_list) * 0.025
        estimated_idr = len(articles_list) * 400
        print(f"\n💰 Estimated Cost:")
        print(f"   USD: ${estimated_cost:.2f}")
        print(f"   IDR: Rp {estimated_idr:,.0f}")
    
    def _print_batch_summary(self, results, success_count, output_dir, articles_list):
        """Print batch summary (ENHANCED)"""
        print(f"\n{'='*70}")
        print(f"✅ BATCH COMPLETED!")
        print(f"{'='*70}")
        print(f"   Success: {success_count}/{len(articles_list)}")
        print(f"   Failed: {len(articles_list) - success_count}/{len(articles_list)}")
        print(f"   Output directory: {output_dir}")
        
        if success_count > 0:
            # Group by type
            types_success = {}
            for result in results:
                if result.get('success'):
                    atype = result.get('metadata', {}).get('article_type', 'unknown')
                    types_success[atype] = types_success.get(atype, 0) + 1
            
            print(f"\n📈 Success by type:")
            for atype, count in sorted(types_success.items()):
                print(f"   - {atype}: {count}")
        
        if len(articles_list) - success_count > 0:
            print(f"\n❌ Failed articles:")
            failed_count = 0
            for idx, result in enumerate(results, 1):
                if not result.get('success'):
                    error = result.get('error', 'Unknown error')
                    print(f"   ❌ Article {idx}: {error[:60]}...")
                    failed_count += 1
                    if failed_count >= 5:  # Limit display to 5 errors
                        remaining = len(articles_list) - success_count - failed_count
                        if remaining > 0:
                            print(f"   ... and {remaining} more errors")
                        break
        
        print(f"{'='*70}\n")
    
    def _slugify(self, text):
        """
        Convert text to URL-friendly slug - NO LENGTH LIMIT
        
        Parameters:
        - text: String text
        
        Returns:
        - str: Slugified text (lowercase, dash-separated, no special chars)
        """
        # Convert ke lowercase
        text = text.lower()
        
        # Replace spasi dengan dash
        text = re.sub(r'\s+', '-', text)
        
        # Remove karakter non-alphanumeric (kecuali dash)
        text = re.sub(r'[^\w-]', '', text)
        
        # Remove multiple dashes
        text = re.sub(r'-+', '-', text)
        
        # Trim dashes di awal dan akhir
        text = text.strip('-')
        
        # NO LENGTH LIMIT - full slug allowed
        return text


# ========== DEMO & TESTING ==========

if __name__ == "__main__":
    
    print("""
╔══════════════════════════════════════════════════════════════════════╗
║                COMPLETE WORKFLOW V4.1 - DEMO                         ║
║                Compatible with Massive Database                      ║
║                Support Story Elements                                ║
╚══════════════════════════════════════════════════════════════════════╝
    """)
    
    # SETUP
    API_KEY = os.environ.get("ANTHROPIC_API_KEY")
    TEMPLATE_PATH = "template.html"
    
    if not API_KEY:
        print("⚠️  WARNING: ANTHROPIC_API_KEY belum di-set!")
        print("\nCara set API key:")
        print("  Windows: set ANTHROPIC_API_KEY=your-key")
        print("  Linux/Mac: export ANTHROPIC_API_KEY=your-key")
        print("\nAtau set langsung di code (tidak recommended)")
        exit()
    
    # Initialize workflow
    try:
        workflow = CompleteWorkflow(
            api_key=API_KEY,
            template_path=TEMPLATE_PATH
        )
    except FileNotFoundError:
        print(f"⚠️  Template tidak ditemukan: {TEMPLATE_PATH}")
        print("\nSiapkan template HTML Anda dulu dengan placeholder:")
        print("  - {{TITLE}}")
        print("  - {{CONTENT}}")
        print("  - {{META_DESCRIPTION}}")
        print("  - {{URL}} (optional)")
        print("  - {{GAMBAR}} (optional)")
        exit()
    
    
    # ===== DEMO 1: Single Article with Story Elements =====
    print("\n" + "="*70)
    print("DEMO 1: Single Article with Story Elements (V4.1)")
    print("="*70)
    
    sample_article = {
        "article_type": "single_player_name",
        "player_name": "Andi",
        "profession": "Driver Ojol",
        "city": "Jakarta",
        "game_name": "Mahjong Ways 2",
        "platform_name": "WINSLOT118",
        "win_amount": "120000000",
        "strategy_type": "pola scatter",
        "clickbait_angle": "Tak Disangka",
        "additional_context": "Main sambil nunggu orderan",
        # Story elements (V4.1)
        "story_action": "scrolling HP",
        "story_discovery": "nemu strategi",
        "story_twist": "scatter bertubi-tubi",
        "story_situation": "lagi nunggu orderan",
        "story_accident": "salah pencet",
        "story_observation": "lihat pola aneh",
        "story_result": "langsung menang"
    }
    
    print("\n📋 Sample Article Data:")
    print(f"   Name: {sample_article['player_name']}")
    print(f"   Profession: {sample_article['profession']}")
    print(f"   Game: {sample_article['game_name']}")
    print(f"   Has Story Elements: Yes")
    
    user_input = input("\nGenerate this article? (y/n): ").lower()
    
    if user_input == 'y':
        result = workflow.run_single(
            article_data=sample_article,
            custom_placeholders={
                "{{AUTHOR}}": "Tim Redaksi",
                "{{URL}}": "https://example.com/article.html",
                "{{GAMBAR}}": "https://via.placeholder.com/1200x630"
            }
        )
        
        if result.get('success'):
            print(f"\n✅ Success!")
            print(f"   HTML: {result['output_path']}")
            print(f"   JSON: {result['json_path']}")
            print(f"   Title: {result['content']['title']}")
    else:
        print("\n❌ Demo cancelled.")
    
    
    # ===== DEMO 2: Batch Generation from JSON =====
    print("\n\n" + "="*70)
    print("DEMO 2: Batch Generation from JSON File")
    print("="*70)
    
    # Try to load from V4.1 generated files
    possible_files = [
        "articles_production_100.json",
        "articles_mixed_15.json",
        "articles_data.json"
    ]
    
    json_file = None
    for filename in possible_files:
        if Path(filename).exists():
            json_file = filename
            break
    
    if json_file:
        print(f"\n📂 Found: {json_file}")
        
        with open(json_file, 'r', encoding='utf-8') as f:
            articles = json.load(f)
        
        print(f"   Total articles: {len(articles)}")
        
        # Ask how many
        try:
            count = input(f"\nGenerate how many? (1-{min(len(articles), 5)}) [default: 3]: ").strip()
            count = int(count) if count else 3
            count = min(count, len(articles), 5)
        except ValueError:
            count = 3
        
        articles_to_generate = articles[:count]
        
        user_input = input(f"\nGenerate {count} articles? Cost: ~${count * 0.025:.2f} (y/n): ").lower()
        
        if user_input == 'y':
            results = workflow.run_batch(
                articles_list=articles_to_generate,
                output_dir="output/demo_v41",
                custom_placeholders={
                    "{{AUTHOR}}": "Tim Redaksi",
                    "{{WEBSITE}}": "SlotNews.com"
                }
            )
            
            print("\n✅ Batch generation completed!")
            print(f"   Check: output/demo_v41/")
        else:
            print("\n❌ Demo cancelled.")
    
    else:
        print(f"\n⚠️  No JSON file found. Run data_generator.py first!")
        print(f"\nTried:")
        for f in possible_files:
            print(f"   - {f}")
    
    
    print("\n" + "="*70)
    print("✨ DEMO COMPLETED!")
    print("="*70)
    print("""
WHAT'S NEW IN V4.1:
✅ Compatible dengan massive database (150+ nama, 100+ profesi, 100+ kota)
✅ Support story elements (7 types)
✅ Enhanced display: show story elements in progress
✅ Enhanced JSON backup: full metadata + input data
✅ Better batch statistics
✅ Improved error handling
✅ Better summary reports

NEXT STEPS:
1. Run data_generator.py untuk generate data
2. Use run_production.py untuk interactive workflow
3. Or use this complete_workflow.py untuk automated batch

SUPPORTED ARTICLE TYPES:
✅ single_player (with story elements)
✅ single_player_name (with story elements)
✅ generic_player (with story elements)
✅ multiple_players (with story elements)
✅ listicle (with story elements)
✅ transformational (with story elements)
    """)