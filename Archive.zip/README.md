# 🚀 Google Discover Content Generator

Script Python untuk generate konten artikel Google Discover otomatis menggunakan AI (Claude) dan mengintegrasikannya dengan template HTML Anda.

## 📋 Fitur

✅ Generate konten artikel berkualitas dengan AI
✅ Support batch generation (multiple artikel sekaligus)  
✅ Integrasi otomatis dengan template HTML Anda  
✅ Tidak menulis template baru - hanya mengisi placeholder  
✅ Struktur konten sesuai best practice Google Discover  
✅ Auto backup ke JSON  
✅ Customizable placeholder & metadata  

---

## 📦 Struktur File

```
project/
├── google_discover_generator.py  # AI Content Generator
├── template_integrator.py        # Template HTML Filler
├── complete_workflow.py           # Complete Workflow
├── template.html                  # Template HTML Anda
├── output/                        # Folder hasil generate
│   ├── article_xxx.html
│   ├── article_xxx.json
│   └── batch/
└── README.md                      # File ini
```

---

## 🔧 Setup & Installation

### 1. Install Dependencies

```bash
pip install anthropic
```

### 2. Setup API Key

Dapatkan API key dari: https://console.anthropic.com/

**Option A: Environment Variable (Recommended)**
```bash
set ANTHROPIC_API_KEY=your-api-key-here
```

**Option B: Langsung di Code**
```python
workflow = CompleteWorkflow(api_key='your-api-key-here')
```

### 3. Siapkan Template HTML

Buat file `template.html` dengan placeholder yang akan diisi otomatis:

```html
<!DOCTYPE html>
<html>
<head>
    <title>{{TITLE}}</title>
    <meta name="description" content="{{META_DESCRIPTION}}">
    <meta property="og:title" content="{{TITLE}}">
    <!-- Meta tags lainnya -->
</head>
<body>
    <h1>{{TITLE}}</h1>
    <div class="content">
        {{CONTENT}}
    </div>
    <footer>
        <p>Penulis: {{AUTHOR}}</p>
        <p>Tanggal: {{DATE}}</p>
    </footer>
</body>
</html>
```

**Placeholder yang Didukung:**
- `{{TITLE}}` / `{title}` - Judul artikel
- `{{CONTENT}}` / `{content}` - Konten artikel (akan diconvert dari markdown ke HTML)
- `{{META_DESCRIPTION}}` / `{description}` - Meta description
- `{{CUSTOM}}` - Custom placeholder apa saja yang Anda tambahkan

---

## 🎯 Cara Penggunaan

### Option 1: Generate Single Article

```python
from complete_workflow import CompleteWorkflow

# Initialize
workflow = CompleteWorkflow(template_path="template.html")

# Data artikel
article_data = {
    "game_name": "Mahjong Ways 2",
    "platform_name": "WINSLOT118",
    "city": "Jakarta",
    "profession": "Driver Ojol",
    "win_amount": "120000000",
    "time_pattern": "malam hari",
    "strategy_type": "pola scatter"
}

# Generate
result = workflow.run_single(
    article_data=article_data,
    custom_placeholders={
        "{{AUTHOR}}": "Admin",
        "{{CATEGORY}}": "Kisah Sukses"
    }
)

print(f"✅ Generated: {result['output_path']}")
```

### Option 2: Batch Generate Multiple Articles

```python
# List artikel
articles = [
    {
        "game_name": "Gates of Olympus",
        "platform_name": "NAGABET76",
        "city": "Surabaya",
        "profession": "Guru",
        "win_amount": "95000000"
    },
    {
        "game_name": "Starlight Princess",
        "platform_name": "WINSLOT118",
        "city": "Bandung",
        "profession": "Mahasiswa",
        "win_amount": "67000000"
    }
]

# Generate batch
results = workflow.run_batch(
    articles_list=articles,
    output_dir="output/batch"
)
```

### Option 3: Load dari JSON File

**Buat file `articles_data.json`:**
```json
[
    {
        "game_name": "Mahjong Ways 2",
        "platform_name": "WINSLOT118",
        "city": "Jakarta",
        "profession": "Tukang Bakso",
        "win_amount": "150000000",
        "time_pattern": "malam hari"
    },
    {
        "game_name": "Sweet Bonanza",
        "platform_name": "NAGABET76",
        "city": "Medan",
        "profession": "Montir",
        "win_amount": "88000000"
    }
]
```

**Load dan generate:**
```python
import json

with open('articles_data.json', 'r') as f:
    articles = json.load(f)

results = workflow.run_batch(articles)
```

---

## 📝 Parameter Input

| Parameter | Required | Deskripsi | Contoh |
|-----------|----------|-----------|--------|
| `game_name` | ✅ | Nama game slot | "Mahjong Ways 2", "Gates of Olympus" |
| `platform_name` | ✅ | Nama platform | "WINSLOT118", "NAGABET76" |
| `city` | ✅ | Kota asal pemain | "Jakarta", "Surabaya", "Bandung" |
| `profession` | ✅ | Profesi pemain | "Driver Ojol", "Tukang Bakso", "Mahasiswa" |
| `win_amount` | ✅ | Nominal kemenangan (rupiah) | "120000000", "95000000" |
| `time_pattern` | ❌ | Waktu bermain | "malam hari", "dini hari", "siang hari" |
| `strategy_type` | ❌ | Jenis strategi | "pola scatter", "trik jitu", "pola petir" |
| `additional_context` | ❌ | Konteks tambahan | "Main sambil jualan" |

---

## 🎨 Struktur Konten yang Di-generate

Setiap artikel akan memiliki struktur:

1. **Judul** (60 karakter, catchy dengan nominal)
2. **Pembuka** (2-3 paragraf hook)
3. **Penjelasan Game** (2-3 paragraf)
4. **Rahasia Strategi** (3-4 paragraf)
5. **Langkah Penerapan** (2-3 paragraf)
6. **Manajemen Modal** (2 paragraf)
7. **Pemanfaatan Bonus** (2 paragraf)
8. **Kisah Detail** (2-3 paragraf)
9. **Penutup** (1-2 paragraf)

**Total:** 700-900 kata

---

## 🔄 Workflow Otomatis

```
Input Data
    ↓
Generate Content dengan AI (Claude)
    ↓
Convert Markdown → HTML
    ↓
Fill Template HTML
    ↓
Save HTML + JSON Backup
    ↓
✅ Output Ready!
```

---

## 📊 Output Files

Setiap artikel menghasilkan 2 file:

**1. HTML File** (`article_xxx.html`)
```html
<!DOCTYPE html>
<html>
<head>
    <title>Driver Ojol Jakarta Raup Rp 120 Juta...</title>
    ...
</head>
<body>
    <h1>Driver Ojol Jakarta Raup Rp 120 Juta...</h1>
    <p>Kisah inspiratif dari seorang driver...</p>
    ...
</body>
</html>
```

**2. JSON Backup** (`article_xxx.json`)
```json
{
    "title": "Driver Ojol Jakarta Raup Rp 120 Juta...",
    "meta_description": "Kisah inspiratif driver ojol...",
    "content": "## Pembuka\n\nKisah inspiratif..."
}
```

---

## ⚡ Tips & Best Practices

### 1. Rate Limiting
Script sudah include delay 2 detik antar request untuk avoid rate limit.

### 2. Variasi Konten
Variasikan input data untuk konten yang lebih natural:
- Ganti nama kota
- Variasi profesi
- Nominal kemenangan berbeda
- Time pattern berbeda

### 3. Template Customization
Sesuaikan template dengan kebutuhan:
- Tambah CSS styling
- Tambah custom placeholder
- Integrasikan dengan CMS
- Tambah tracking code

### 4. Backup JSON
Selalu simpan JSON backup untuk:
- Re-generate jika template berubah
- Editing manual
- Database import

### 5. SEO Optimization
- Judul max 60 karakter
- Meta description 150-160 karakter
- Gunakan heading hierarchy (H1, H2)
- Internal linking

---

## 🐛 Troubleshooting

### Error: "ANTHROPIC_API_KEY not found"
**Solusi:** Set API key di environment atau langsung di code

### Error: "Template file not found"
**Solusi:** Pastikan path template benar dan file ada

### Error: "Rate limit exceeded"
**Solusi:** Tambah delay di batch generation atau tunggu beberapa menit

### Konten tidak sesuai
**Solusi:** 
- Sesuaikan prompt di `google_discover_generator.py`
- Tambah `additional_context` untuk guidance lebih spesifik

### HTML formatting rusak
**Solusi:** 
- Cek placeholder di template
- Pastikan markdown conversion berjalan
- Periksa function `_convert_markdown_to_html()`

---

## 📚 Advanced Usage

### Custom AI Model
```python
# Di google_discover_generator.py, ubah model:
response = self.client.messages.create(
    model="claude-sonnet-4-20250514",  # Ganti sesuai kebutuhan
    max_tokens=4096,
    ...
)
```

### Custom Prompt
Edit prompt di function `generate_content()` untuk sesuaikan style konten.

### Database Integration
```python
# Contoh save ke database
result = workflow.run_single(article_data)

if result['success']:
    db.insert({
        'title': result['content']['title'],
        'content': result['content']['content'],
        'html_path': result['output_path']
    })
```

---

## 📞 Support

Jika ada pertanyaan atau issue:
1. Cek troubleshooting section di atas
2. Review contoh penggunaan di `complete_workflow.py`
3. Lihat comment di dalam code untuk detail teknis

---

## 🎓 Example Use Cases

### Use Case 1: Daily Content Production
```python
# Generate 10 artikel setiap hari
daily_articles = load_from_csv('daily_articles.csv')
results = workflow.run_batch(daily_articles, output_dir='output/daily')
```

### Use Case 2: A/B Testing
```python
# Generate 2 versi konten untuk A/B test
for version in ['A', 'B']:
    result = workflow.run_single(
        article_data,
        output_path=f'output/version_{version}.html'
    )
```

### Use Case 3: Multi-Platform
```python
# Generate untuk berbagai platform
platforms = ['WINSLOT118', 'NAGABET76', 'SLOT88']

for platform in platforms:
    article_data['platform_name'] = platform
    workflow.run_single(article_data)
```

---

## ✨ Features Roadmap

- [ ] CSV input support
- [ ] WordPress integration
- [ ] Image generation with AI
- [ ] Multi-language support
- [ ] Analytics tracking
- [ ] Auto publishing to CMS
- [ ] Content scheduling

---

## 📜 License

MIT License - Free to use and modify

---

**Happy Content Generating! 🚀**