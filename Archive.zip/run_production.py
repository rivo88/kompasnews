"""
INTERACTIVE PRODUCTION SCRIPT V4.1
===================================

Script untuk generate artikel dengan input interaktif:
- Base URL (input 1x)
- URL Gambar per artikel (input setiap artikel)

UPDATED: Compatible dengan data_generator.py V4.1
- Support massive database
- Support story elements
- Better display info

Author: AI Assistant
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path

from google_discover_generator import GoogleDiscoverContentGenerator
from template_integrator import TemplateIntegrator


class InteractiveWorkflow:
    """Workflow dengan interactive input"""
    
    def __init__(self, api_key=None, template_path="template.html"):
        """Initialize workflow"""
        self.generator = GoogleDiscoverContentGenerator(api_key)
        self.template_path = template_path
        self.base_url = None
    
    def run_interactive(self, articles_list, output_dir="output/interactive"):
        """
        Jalankan workflow dengan interactive input
        
        Parameters:
        - articles_list: List of dict article data
        - output_dir: Directory output
        
        Returns:
        - List of results
        """
        
        print("""
╔══════════════════════════════════════════════════════════════════════╗
║              INTERACTIVE ARTICLE GENERATOR V4.1                      ║
║              Compatible with Massive Database                        ║
╚══════════════════════════════════════════════════════════════════════╝
        """)
        
        # Step 1: Input Base URL (sekali di awal)
        self.base_url = self._input_base_url()
        
        print(f"\n✅ Base URL set: {self.base_url}")
        print(f"📊 Total articles to generate: {len(articles_list)}")
        print(f"💰 Estimated cost: ${len(articles_list) * 0.025:.2f} (Rp {len(articles_list) * 400:,.0f})")
        
        # Show types distribution
        self._show_types_distribution(articles_list)
        
        # Confirmation
        confirm = input(f"\nContinue? (y/n): ").lower().strip()
        if confirm != 'y':
            print("❌ Cancelled.")
            return []
        
        # Create output directory
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        
        # Step 2: Loop generate per artikel
        results = []
        success_count = 0
        
        for idx, article_data in enumerate(articles_list, 1):
            print(f"\n{'='*70}")
            print(f"[{idx}/{len(articles_list)}] PROCESSING ARTICLE")
            print(f"{'='*70}")
            
            try:
                result = self._process_single_article(
                    article_data=article_data,
                    article_number=idx,
                    total_articles=len(articles_list),
                    output_dir=output_dir
                )
                
                results.append(result)
                
                if result.get('success'):
                    success_count += 1
                    
            except KeyboardInterrupt:
                print(f"\n\n⚠️  INTERRUPTED BY USER!")
                print(f"✅ Successfully saved: {success_count} articles")
                print(f"📁 Location: {output_dir}")
                sys.exit(0)
                
            except Exception as e:
                print(f"\n❌ Unexpected error: {e}")
                result = {
                    "success": False,
                    "error": str(e),
                    "article_number": idx
                }
                results.append(result)
                
                # Save progress and stop
                print(f"\n⚠️  STOPPED due to error!")
                print(f"✅ Successfully saved: {success_count} articles")
                print(f"📁 Location: {output_dir}")
                break
            
            # Rate limiting
            if idx < len(articles_list):
                import time
                time.sleep(2)
        
        # Final summary
        self._print_summary(results, success_count, output_dir)
        
        return results
    
    def _show_types_distribution(self, articles_list):
        """Show distribution of article types"""
        types_count = {}
        for article in articles_list:
            atype = article.get('article_type', 'unknown')
            types_count[atype] = types_count.get(atype, 0) + 1
        
        print("\n📈 Article Types:")
        for atype, count in sorted(types_count.items()):
            print(f"   - {atype}: {count}")
    
    def _input_base_url(self):
        """Input base URL dari user"""
        print("\n📍 BASE URL SETUP")
        print("="*70)
        print("Contoh: https://example.com/pages/")
        print("        https://example.com/articles/")
        
        while True:
            url = input("\nBase URL: ").strip()
            
            if not url:
                print("❌ URL tidak boleh kosong!")
                continue
            
            # Pastikan diakhiri dengan /
            if not url.endswith('/'):
                url += '/'
            
            return url
    
    def _process_single_article(self, article_data, article_number, total_articles, output_dir):
        """Process satu artikel dengan interactive input"""
        
        article_type = article_data.get('article_type', 'single_player')
        game_name = article_data.get('game_name', 'Game')
        platform_name = article_data.get('platform_name', 'Platform')
        win_amount = article_data.get('win_amount', '0')
        
        # Display info (ENHANCED - show more details)
        print(f"\n📝 Type: {article_type}")
        print(f"🎮 Game: {game_name}")
        print(f"🏆 Platform: {platform_name}")
        print(f"💰 Win: Rp {int(win_amount):,}")
        
        # Show type-specific info
        if article_type == "single_player_name":
            name = article_data.get('player_name', '-')
            profession = article_data.get('profession', '-')
            print(f"👤 Player: {name} ({profession})")
        elif article_type == "single_player":
            profession = article_data.get('profession', '-')
            city = article_data.get('city', '-')
            print(f"👤 Profile: {profession} - {city}")
        elif article_type == "multiple_players":
            count = article_data.get('player_count', 3)
            print(f"👥 Players: {count} orang")
        elif article_type == "listicle":
            tips = article_data.get('tip_count', 5)
            print(f"📋 Tips: {tips} trik")
        
        # Show story elements if available (NEW in V4.1)
        story_elements = []
        if article_data.get('story_situation'):
            story_elements.append(f"Situasi: {article_data['story_situation']}")
        if article_data.get('story_action'):
            story_elements.append(f"Action: {article_data['story_action']}")
        if article_data.get('story_result'):
            story_elements.append(f"Result: {article_data['story_result']}")
        
        if story_elements:
            print(f"📖 Story: {' → '.join(story_elements[:2])}")
        
        # Step 1: Generate content dengan AI
        print(f"\n⏳ Generating content with AI...")
        
        try:
            content_data = self.generator.generate_content(**article_data)
            print(f"✅ Content generated!")
            print(f"📄 Title: {content_data['title']}")
            print(f"📏 Length: ~{len(content_data['content'])} characters")
        except Exception as e:
            print(f"❌ Error generating content: {e}")
            return {
                "success": False,
                "error": f"Content generation failed: {str(e)}",
                "article_number": article_number
            }
        
        # Step 2: Input URL Gambar (INTERAKTIF)
        print(f"\n{'─'*70}")
        image_url = self._input_image_url(article_number, total_articles, content_data['title'])
        
        # Step 3: Generate full URL
        filename = self._slugify(content_data['title']) + '.html'
        full_url = self.base_url + filename
        
        print(f"\n🔗 Full URL: {full_url}")
        
        # Step 4: Fill template
        try:
            integrator = TemplateIntegrator(self.template_path)
            
            output_path = str(Path(output_dir) / filename)
            
            # Custom placeholders dengan URL dan GAMBAR
            custom_placeholders = {
                "{{URL}}": full_url,
                "{{GAMBAR}}": image_url,
                "{{DATE}}": datetime.now().strftime("%d %B %Y"),
                "{{PLATFORM}}": platform_name,
                "{{GAME}}": game_name,
            }
            
            integrator.fill_template(
                content_data=content_data,
                output_path=output_path,
                custom_placeholders=custom_placeholders
            )
            
            print(f"💾 HTML saved: {output_path}")
            
            # Save JSON backup (ENHANCED - include all metadata)
            json_path = output_path.replace('.html', '.json')
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump({
                    **content_data,
                    "metadata": {
                        "url": full_url,
                        "image_url": image_url,
                        "article_type": article_type,
                        "game_name": game_name,
                        "platform_name": platform_name,
                        "win_amount": win_amount,
                        "generated_at": datetime.now().isoformat()
                    },
                    "input_data": article_data
                }, f, ensure_ascii=False, indent=2)
            
            print(f"💾 JSON backup: {json_path}")
            
            return {
                "success": True,
                "title": content_data['title'],
                "url": full_url,
                "image_url": image_url,
                "output_path": output_path,
                "json_path": json_path,
                "article_number": article_number,
                "article_type": article_type
            }
            
        except Exception as e:
            print(f"❌ Error filling template: {e}")
            return {
                "success": False,
                "error": f"Template error: {str(e)}",
                "article_number": article_number,
                "content_data": content_data
            }
    
    def _input_image_url(self, article_number, total_articles, title):
        """Input URL gambar dari user (no validasi)"""
        print(f"\n🖼️  IMAGE URL INPUT [{article_number}/{total_articles}]")
        print(f"Article: {title[:60]}...")
        print("─"*70)
        print("Paste image URL (or press Enter to skip):")
        
        image_url = input("URL Gambar: ").strip()
        
        # Default image if empty
        if not image_url:
            image_url = "https://via.placeholder.com/1200x630?text=Article+Image"
            print(f"⚠️  Using placeholder: {image_url}")
        
        return image_url
    
    def _slugify(self, text):
        """Convert text to URL-friendly slug"""
        import re
        text = text.lower()
        text = re.sub(r'\s+', '-', text)
        text = re.sub(r'[^\w-]', '', text)
        text = re.sub(r'-+', '-', text)
        text = text.strip('-')
        return text
    
    def _print_summary(self, results, success_count, output_dir):
        """Print summary hasil generation"""
        print(f"\n\n{'='*70}")
        print("📊 GENERATION SUMMARY")
        print(f"{'='*70}")
        print(f"✅ Success: {success_count}/{len(results)}")
        print(f"❌ Failed: {len(results) - success_count}/{len(results)}")
        print(f"📁 Location: {output_dir}")
        
        if success_count > 0:
            # Group by type
            types_success = {}
            for result in results:
                if result.get('success'):
                    atype = result.get('article_type', 'unknown')
                    types_success[atype] = types_success.get(atype, 0) + 1
            
            print(f"\n📈 Success by type:")
            for atype, count in sorted(types_success.items()):
                print(f"   - {atype}: {count}")
            
            print(f"\n📄 Generated files:")
            for result in results:
                if result.get('success'):
                    print(f"   ✅ {Path(result['output_path']).name}")
        
        if len(results) - success_count > 0:
            print(f"\n❌ Failed articles:")
            for result in results:
                if not result.get('success'):
                    print(f"   ❌ Article {result.get('article_number')}: {result.get('error')}")
        
        print(f"{'='*70}\n")


# ========== MAIN EXECUTION ==========

if __name__ == "__main__":
    
    # Check API key
    API_KEY = os.environ.get("ANTHROPIC_API_KEY")
    if not API_KEY:
        print("⚠️  ERROR: ANTHROPIC_API_KEY not set!")
        print("\nSet your API key:")
        print("  Windows: set ANTHROPIC_API_KEY=your-key")
        print("  Linux/Mac: export ANTHROPIC_API_KEY=your-key")
        sys.exit(1)
    
    # Check template
    if not Path("template.html").exists():
        print("⚠️  ERROR: template.html not found!")
        print("Make sure template.html exists with {{URL}} and {{GAMBAR}} placeholders")
        sys.exit(1)
    
    # UPDATED: Try multiple JSON files (support V4.1 filenames)
    possible_files = [
        "articles_production_100.json",  # From V4.1
        "articles_mixed_15.json",         # From V3.0
        "articles_data.json"              # Generic
    ]
    
    json_file = None
    for filename in possible_files:
        if Path(filename).exists():
            json_file = filename
            break
    
    if not json_file:
        print(f"⚠️  ERROR: No article JSON found!")
        print(f"\nTried looking for:")
        for f in possible_files:
            print(f"  - {f}")
        print(f"\nRun this first:")
        print(f"  python data_generator.py")
        sys.exit(1)
    
    print(f"📂 Loading articles from: {json_file}")
    with open(json_file, 'r', encoding='utf-8') as f:
        articles = json.load(f)
    
    print(f"✅ Loaded {len(articles)} articles\n")
    
    # Show sample article info
    if len(articles) > 0:
        sample = articles[0]
        print(f"📋 Sample article:")
        print(f"   Type: {sample.get('article_type')}")
        print(f"   Game: {sample.get('game_name')}")
        print(f"   Has story elements: {'Yes' if sample.get('story_action') else 'No'}")
        print()
    
    # Ask how many to generate
    print("How many articles to generate?")
    print(f"  Available: {len(articles)} articles")
    
    try:
        count = input(f"Generate (1-{len(articles)}) [default: all]: ").strip()
        count = int(count) if count else len(articles)
        count = min(count, len(articles))
    except ValueError:
        count = len(articles)
    
    articles_to_generate = articles[:count]
    
    print(f"\n✅ Will generate {count} articles")
    
    # Initialize workflow
    workflow = InteractiveWorkflow(
        api_key=API_KEY,
        template_path="template.html"
    )
    
    # Run interactive generation
    results = workflow.run_interactive(
        articles_list=articles_to_generate,
        output_dir="output/interactive"
    )
    
    print("\n✨ DONE!")
    print("\n💡 TIP: Check output/interactive/ folder for your generated articles!")