import json
import re
from pathlib import Path

class TemplateIntegrator:
    """
    Class untuk mengintegrasikan konten yang di-generate AI dengan template HTML
    VERSION 4.2 - Google Discover Optimized
    
    UPDATED V4.2:
    - Enhanced sanitization untuk title & meta description
    - Remove ALL markdown symbols (#, **, *, dll)
    - Clean hashtags from meta
    - Validation untuk meta length (max 155 chars)
    """
    
    def __init__(self, template_path):
        """Initialize dengan path ke template HTML"""
        self.template_path = Path(template_path)
        
        if not self.template_path.exists():
            raise FileNotFoundError(f"Template tidak ditemukan: {template_path}")
        
        with open(self.template_path, 'r', encoding='utf-8') as f:
            self.template_content = f.read()
    
    def fill_template(self, content_data, output_path=None, custom_placeholders=None):
        """
        Isi template dengan konten yang sudah di-generate
        
        Parameters:
        - content_data: Dict hasil dari generator.generate_content()
                       Harus punya keys: title, content, meta_description
        - output_path: Path output file HTML (optional)
        - custom_placeholders: Dict mapping custom placeholder ke data
                              Contoh: {
                                  "{{AUTHOR}}": "Admin",
                                  "{{URL}}": "https://example.com/article.html",
                                  "{{GAMBAR}}": "https://cdn.example.com/img.jpg"
                              }
        
        Returns:
        - str: HTML yang sudah terisi
        """
        
        filled_html = self.template_content
        
        # CRITICAL V4.2: Sanitize title & meta BEFORE inserting
        title_clean = self._sanitize_title(content_data.get('title', ''))
        meta_clean = self._sanitize_meta_description(content_data.get('meta_description', ''))
        content_html = self._convert_markdown_to_html(content_data.get('content', ''))
        
        # Mapping default placeholder ke data
        default_mappings = {
            # Title variations (SANITIZED)
            "{{TITLE}}": title_clean,
            "{{title}}": title_clean,
            "{title}": title_clean,
            
            # Content variations (convert markdown to HTML)
            "{{CONTENT}}": content_html,
            "{{content}}": content_html,
            "{content}": content_html,
            
            # Meta description variations (SANITIZED)
            "{{META_DESCRIPTION}}": meta_clean,
            "{{meta_description}}": meta_clean,
            "{description}": meta_clean,
            "{meta_description}": meta_clean,
            "{{DESCRIPTION}}": meta_clean,
            "{{description}}": meta_clean,
            
            # Meta title variations (SANITIZED)
            "{{META_TITLE}}": title_clean,
            "{{meta_title}}": title_clean,
            "{meta_title}": title_clean,
        }
        
        # Replace default placeholders
        for placeholder, value in default_mappings.items():
            filled_html = filled_html.replace(placeholder, value)
        
        # Replace custom placeholders jika ada (termasuk {{URL}} dan {{GAMBAR}})
        if custom_placeholders:
            for placeholder, value in custom_placeholders.items():
                filled_html = filled_html.replace(placeholder, str(value))
        
        # Save ke file jika output_path diberikan
        if output_path:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(filled_html)
            
            print(f"✅ HTML file created: {output_path}")
        
        return filled_html
    
    def _sanitize_title(self, title):
        """
        CRITICAL V4.2: Clean title dari markdown symbols
        
        Removes:
        - # (heading symbols)
        - ** (bold)
        - * (italic)
        - _ (underscore)
        - ` (backticks)
        """
        if not title:
            return ""
        
        # Remove markdown heading symbols
        title = title.lstrip('#').strip()
        
        # Remove bold/italic markers
        title = title.replace('**', '').replace('*', '')
        title = title.replace('__', '').replace('_', '')
        
        # Remove backticks
        title = title.replace('`', '')
        
        # Clean multiple spaces
        title = re.sub(r'\s+', ' ', title)
        
        return title.strip()
    
    def _sanitize_meta_description(self, meta):
        """
        CRITICAL V4.2: Clean meta description
        
        Removes:
        - # hashtags
        - ** bold
        - * italic
        - All special markdown symbols
        
        Validates:
        - Max 155 characters
        """
        if not meta:
            return ""
        
        # Remove ALL markdown symbols
        meta = meta.lstrip('#').strip()
        meta = meta.replace('#', '')  # Remove ALL hashtags
        meta = meta.replace('**', '').replace('*', '')
        meta = meta.replace('__', '').replace('_', '')
        meta = meta.replace('`', '')
        
        # Clean multiple spaces
        meta = re.sub(r'\s+', ' ', meta)
        
        # Validate length (max 155 chars)
        if len(meta) > 155:
            meta = meta[:152] + '...'
        
        return meta.strip()
    
    def _convert_markdown_to_html(self, markdown_text):
        """
        Convert markdown sederhana ke HTML
        
        V4.2: Support bold keywords for SEO
        - **text** → <strong>text</strong>
        - ## Heading → <h2>Heading</h2>
        """
        html = markdown_text
        
        # Convert heading level 2 (## Heading)
        html = re.sub(r'^## (.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
        
        # Convert heading level 3 (### Heading)
        html = re.sub(r'^### (.+)$', r'<h3>\1</h3>', html, flags=re.MULTILINE)
        
        # Convert bold (**text**) - KEEP THIS for SEO keywords
        html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
        
        # Convert italic (*text*)
        html = re.sub(r'\*(.+?)\*', r'<em>\1</em>', html)
        
        # Convert paragraphs (double newline = new paragraph)
        paragraphs = html.split('\n\n')
        html_paragraphs = []
        
        for para in paragraphs:
            para = para.strip()
            if para:
                # Skip jika sudah ada tag HTML (heading, dll)
                if not para.startswith('<'):
                    para = f'<p>{para}</p>'
                html_paragraphs.append(para)
        
        html = '\n'.join(html_paragraphs)
        
        # Bersihkan single newline di dalam paragraf (jadi space)
        html = re.sub(r'(?<!>)\n(?!<)', ' ', html)
        
        return html
    
    def _slugify(self, text):
        """Convert text to URL-friendly slug"""
        # Remove markdown first
        text = self._sanitize_title(text)
        
        text = text.lower()
        text = re.sub(r'\s+', '-', text)
        text = re.sub(r'[^\w-]', '', text)
        text = re.sub(r'-+', '-', text)
        text = text.strip('-')
        return text


# ========== TESTING ==========

if __name__ == "__main__":
    
    print("""
╔════════════════════════════════════════════════════════════════╗
║     TEMPLATE INTEGRATOR V4.2 - TESTING                        ║
║     Enhanced Sanitization for Google Discover                 ║
╚════════════════════════════════════════════════════════════════╝
    """)
    
    # Test sanitization
    print("\n" + "="*60)
    print("TEST 1: Title Sanitization")
    print("="*60)
    
    test_titles = [
        "# Mawar Lihat Mahjong Wins 3 Bergerak Aneh",
        "**Sigit** Blogger Lihat Iklan",
        "# **Ibu Penjual** Es Kelapa Salah Pencet",
        "Normal Title Tanpa Markdown"
    ]
    
    integrator = TemplateIntegrator.__new__(TemplateIntegrator)
    
    for title in test_titles:
        clean = integrator._sanitize_title(title)
        print(f"\nOriginal: {title}")
        print(f"Cleaned:  {clean}")
        print(f"Has #? {'YES ❌' if '#' in clean else 'NO ✅'}")
        print(f"Has **? {'YES ❌' if '**' in clean else 'NO ✅'}")
    
    print("\n" + "="*60)
    print("TEST 2: Meta Description Sanitization")
    print("="*60)
    
    test_metas = [
        "# MC Padang Raup Rp 67 Juta dari Mahjong Wins 2",
        "Seorang **pemain** dari Jakarta mengalami kejadian #unik",
        "Plain text meta description yang normal",
        "Meta description yang terlalu panjang dan harus dipotong karena melebihi 155 karakter limit yang ditentukan oleh Google untuk optimal display di search results dan discover feed"
    ]
    
    for meta in test_metas:
        clean = integrator._sanitize_meta_description(meta)
        print(f"\nOriginal ({len(meta)} chars): {meta[:80]}...")
        print(f"Cleaned ({len(clean)} chars):  {clean}")
        print(f"Has #? {'YES ❌' if '#' in clean else 'NO ✅'}")
        print(f"Length OK? {'YES ✅' if len(clean) <= 155 else 'NO ❌'}")
    
    print("\n" + "="*60)
    print("TEST 3: Markdown to HTML Conversion")
    print("="*60)
    
    test_content = """
## Kejadian Tak Terduga

Mawar sedang **bermain game** saat tiba-tiba layar *berkedip*. Kejadian ini membuat dia terkejut.

## Hasil Akhir

Setelah beberapa saat, scatter **Mahjong Wins 3** muncul beruntun.
"""
    
    html = integrator._convert_markdown_to_html(test_content)
    print("\nMarkdown Input:")
    print(test_content)
    print("\nHTML Output:")
    print(html)
    
    print("\n" + "="*60)
    print("✨ TESTING COMPLETED!")
    print("="*60)
    print("""
SANITIZATION FEATURES V4.2:
✅ Remove # from title & meta
✅ Remove ** bold markers from title & meta  
✅ Remove * italic markers from title & meta
✅ Validate meta length (max 155 chars)
✅ Keep **bold** in content for SEO keywords
✅ Convert markdown to proper HTML in content

READY FOR PRODUCTION!
    """)