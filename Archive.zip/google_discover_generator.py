import os
import json
from anthropic import Anthropic
from datetime import datetime

class GoogleDiscoverContentGenerator:
    """
    Generator konten artikel Google Discover menggunakan Claude AI
    VERSION 4.2 - GOOGLE DISCOVER OPTIMIZED
    
    UPDATED V4.2:
    - NO hashtags/markdown in title & meta
    - Shorter content: 600-800 words
    - FAQ section mandatory
    - Neutral & educational tone
    - Bold keywords
    - Disclaimer about RNG
    
    Compatible dengan data_generator.py V4.1
    """
    
    def __init__(self, api_key=None):
        """
        Inisialisasi generator dengan API key
        
        Parameters:
        - api_key: Anthropic API key (optional, bisa pakai environment variable)
        """
        self.client = Anthropic(api_key=api_key or os.environ.get("ANTHROPIC_API_KEY"))
        
    def generate_content(self, **article_data):
        """
        Generate konten artikel untuk Google Discover
        Optimized untuk masuk Google Discover dengan FAQ & neutral tone
        
        Parameters (via **article_data):
        - article_type: Type artikel
        - game_name, platform_name, win_amount (WAJIB)
        - story_action, story_discovery, story_twist, story_situation, dll (OPTIONAL)
        - Parameter lain tergantung article_type
        
        Returns:
        - dict: {"title": str, "content": str, "meta_description": str}
        """
        
        # Get article type
        article_type = article_data.get('article_type', 'single_player')
        
        # Extract common data
        game_name = article_data.get('game_name', 'Game')
        platform_name = article_data.get('platform_name', 'Platform')
        win_amount = article_data.get('win_amount', '100000000')
        
        # Format nominal
        win_amount_formatted = self._format_rupiah(win_amount)
        
        # Build prompt based on article type
        prompt = self._build_prompt(article_type, article_data, win_amount_formatted)
        
        try:
            # Call Claude API
            response = self.client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=4096,
                temperature=0.7,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            
            # Parse response
            content_text = response.content[0].text
            
            # Try to extract JSON from response
            try:
                start_idx = content_text.find('{')
                end_idx = content_text.rfind('}') + 1
                
                if start_idx != -1 and end_idx > start_idx:
                    json_str = content_text[start_idx:end_idx]
                    result = json.loads(json_str)
                    
                    # CRITICAL: Clean title & meta from markdown/hashtags
                    result = self._sanitize_output(result)
                else:
                    raise ValueError("JSON tidak ditemukan dalam response")
                    
            except (json.JSONDecodeError, ValueError) as e:
                # Fallback: buat struktur manual jika JSON parsing gagal
                print(f"⚠️  Warning: JSON parsing failed, creating manual structure")
                result = self._create_fallback_result(article_type, article_data, win_amount_formatted, content_text)
            
            return result
            
        except Exception as e:
            raise Exception(f"Error generating content: {str(e)}")
    
    def _sanitize_output(self, result):
        """
        CRITICAL: Clean title & meta_description dari markdown/hashtags
        """
        if 'title' in result:
            # Remove markdown heading symbols
            result['title'] = result['title'].lstrip('#').strip()
            # Remove other markdown
            result['title'] = result['title'].replace('**', '').replace('*', '')
            
        if 'meta_description' in result:
            # Remove ALL special characters from meta
            result['meta_description'] = result['meta_description'].lstrip('#').strip()
            result['meta_description'] = result['meta_description'].replace('**', '').replace('*', '')
            result['meta_description'] = result['meta_description'].replace('#', '')
            # Limit to 155 characters
            if len(result['meta_description']) > 155:
                result['meta_description'] = result['meta_description'][:152] + '...'
        
        return result
    
    def _build_prompt(self, article_type, data, win_formatted):
        """Build prompt berdasarkan article type + story elements"""
        
        game = data.get('game_name', 'Game')
        platform = data.get('platform_name', 'Platform')
        
        # Extract story elements
        story_action = data.get('story_action', '')
        story_discovery = data.get('story_discovery', '')
        story_twist = data.get('story_twist', '')
        story_situation = data.get('story_situation', '')
        story_accident = data.get('story_accident', '')
        story_observation = data.get('story_observation', '')
        story_result = data.get('story_result', '')
        
        # Build story context section
        story_context = self._build_story_context(
            story_action, story_discovery, story_twist, 
            story_situation, story_accident, story_observation, story_result
        )
        
        # Base prompt components (UPDATED V4.2)
        base_guidelines = """
**CRITICAL GUIDELINES V4.2 - GOOGLE DISCOVER OPTIMIZED:**

**OUTPUT FORMAT:**
Return HANYA JSON dengan format:
```json
{
  "title": "Title di sini - PLAIN TEXT, NO # markdown, NO ** bold",
  "meta_description": "Meta description - PLAIN TEXT, NO # hashtag, NO special chars, max 150 karakter",
  "content": "Full article content di sini"
}
```

**TITLE RULES (CRITICAL):**
- PLAIN TEXT - NO `#`, NO `**`, NO markdown symbols
- Bahasa Indonesia natural, Title Case pada kata penting
- Panjang: 60-80 kata MAKSIMAL
- Format: "[Nama/Profesi] [Action] [Game] [Connector: malah/saat/lalu] [Twist/Result]"
- Contoh BENAR: "Ibu Penjual Es Kelapa Salah Pencet Video Malah Temu Strategi Mahjong Wins 5"
- Contoh SALAH: "# Ibu Penjual Es Kelapa..." atau "**Ibu Penjual**..."

**META DESCRIPTION RULES (CRITICAL):**
- PLAIN TEXT - NO `#`, NO `**`, NO special characters
- Panjang: 130-150 karakter MAKSIMAL
- Fokus pada CERITA/KEJADIAN, bukan nominal kemenangan
- Netral & objektif
- Contoh: "Seorang ibu penjual es kelapa tak sengaja menemukan strategi game saat salah menekan video. Kejadian tak terduga yang menarik perhatian."

**CONTENT GUIDELINES:**
- Total panjang: **600-800 kata** (lebih pendek dari sebelumnya!)
- Bahasa Indonesia natural, casual tapi informatif
- Setiap section pakai subheading (## Heading)
- Tone: **NETRAL, OBJEKTIF, EDUKATIF**
- **Bold** pada nama game: `**{game}**`
- **Bold** pada istilah penting: `**RNG**`, `**strategi**`, `**scatter**`

**MANDATORY SECTIONS:**
1. Intro (2-3 paragraf)
2. Body (3-4 sections dengan ## subheading)
3. **FAQ Section** (WAJIB! 4-5 pertanyaan)
4. Kesimpulan (1-2 paragraf)

**TONE & DISCLAIMER (CRITICAL):**
- HINDARI over-promising: "dijamin menang", "pasti jackpot"
- TAMBAHKAN disclaimer: "hasil bervariasi", "tergantung RNG", "tidak ada jaminan"
- Fokus pada CERITA & PROSES, bukan hasil akhir
- Educational value > Promotional hype
- Skeptis tapi fair: "mengklaim berhasil, namun belum ada verifikasi independen"

**FAQ SECTION FORMAT:**
```
## FAQ: [Topik Artikel]

**Pertanyaan 1?**
Jawaban singkat dalam 2-3 kalimat. Netral dan informatif.

**Pertanyaan 2?**
Jawaban dengan disclaimer jika perlu. Mention RNG atau verifikasi.

**Pertanyaan 3?**
Jawaban yang membantu pembaca memahami topik.

**Pertanyaan 4?**
Takeaway message atau pesan utama.
```

CRITICAL FAQ FORMATTING:
- Pertanyaan WAJIB **bold** dengan format: **Pertanyaan di sini?**
- Setiap Q&A dipisah dengan SATU blank line
- Jawaban plain text, 2-3 kalimat maksimal
- Total 4-5 pasangan Q&A
- Pertanyaan harus jelas dan to the point

**VERIFICATION & CREDIBILITY:**
- Mention: "perlu verifikasi lebih lanjut"
- Remind: "game menggunakan sistem RNG"
- Emphasize: "hasil dapat bervariasi"

CRITICAL: Output HARUS JSON! Title & meta HARUS plain text tanpa markdown!
}
"""
        
        # Prompt per article type
        if article_type == "single_player":
            profession = data.get('profession', 'Player')
            city = data.get('city', 'Jakarta')
            location_prefix = data.get('location_prefix', '')
            clickbait_angle = data.get('clickbait_angle', 'Kisah Unik')
            strategy = data.get('strategy_type', 'pola gacor')
            context = data.get('additional_context', '')
            
            location = f"{location_prefix} {city}".strip() if location_prefix else city
            
            return f"""Buatkan artikel Google Discover OPTIMIZED dengan spesifikasi:

**ARTICLE TYPE:** Single Player (dengan profesi)

**DATA:**
- Profesi: {profession}
- Lokasi: {location}
- Game: {game}
- Platform: {platform}
- Kemenangan: {win_formatted}
- Angle: {clickbait_angle}
- Strategi: {strategy}
{f'- Context: {context}' if context else ''}

{story_context}

**TITLE FORMAT (60-80 kata, NO # markdown):**
"{profession} {location} [action dari story] **{game}** malah/saat/lalu [twist/result]"

**META DESCRIPTION (130-150 char, NO # hashtag, fokus cerita):**
Cerita singkat tentang {profession} dari {location} yang mengalami kejadian tak terduga saat {story_situation}.

**STRUKTUR ARTIKEL (600-800 kata):**
1. **Intro** - Kejadian {profession} dari {location}, situasi: {story_situation}
2. **Kejadian Awal** - Saat {story_action}, kemudian {story_discovery}
3. **Tentang Game** - **{game}** features (bold game name!)
4. **Strategi yang Ditemukan** - {strategy}, mention disclaimer RNG
5. **Momen Dramatis** - {story_twist}
6. **Hasil & Verifikasi** - {story_result}, dengan catatan "perlu verifikasi"
7. **## FAQ: [Judul Topik]** (WAJIB - 4-5 Q&A dengan format proper)
8. **Kesimpulan** - Netral, edukatif, tidak over-promising

**CONTOH FAQ YANG BAIK:**
```
## FAQ: Strategi {game}

**Apakah strategi ini benar-benar efektif?**
Beberapa pemain melaporkan hasil positif, namun perlu diingat bahwa game ini menggunakan sistem RNG. Hasil dapat bervariasi untuk setiap pemain.

**Bagaimana cara menemukan pola seperti ini?**
Observasi konsisten dan pencatatan hasil permainan dapat membantu mengidentifikasi pola. Namun tidak ada jaminan pola akan berulang.

**Apakah game ini menggunakan RNG?**
Ya, seperti kebanyakan game slot online, {game} menggunakan Random Number Generator untuk memastikan hasil permainan yang fair dan acak.

**Bolehkah pemain lain mencoba strategi ini?**
Tentu, namun harap diingat bahwa hasil tidak dapat dijamin sama. Selalu bermain dengan bijak dan tetapkan batasan.
```

{base_guidelines}"""

        elif article_type == "single_player_name":
            player_name = data.get('player_name', 'Andi')
            profession = data.get('profession', 'Player')
            city = data.get('city', 'Jakarta')
            strategy = data.get('strategy_type', 'pola sederhana')
            context = data.get('additional_context', '')
            
            return f"""Buatkan artikel Google Discover OPTIMIZED dengan spesifikasi:

**ARTICLE TYPE:** Single Player dengan Nama

**DATA:**
- Nama: {player_name}
- Profesi: {profession}
- Kota: {city}
- Game: {game}
- Platform: {platform}
- Kemenangan: {win_formatted}
- Strategi: {strategy}
{f'- Context: {context}' if context else ''}

{story_context}

**TITLE FORMAT (60-80 kata, PLAIN TEXT, NO # markdown):**
"{player_name} {profession} [action] **{game}** malah/saat [twist/result]"
Contoh: "Mawar Lihat Mahjong Wins 3 Bergerak Aneh Saat Monitornya Munculkan Bayangan Gelap"

**META DESCRIPTION (130-150 char, PLAIN TEXT, NO hashtag):**
Cerita {player_name}, seorang {profession} dari {city} yang mengalami kejadian tak terduga saat bermain.

**ALUR CERITA {player_name.upper()}:**
{player_name} sedang {story_situation} → {story_action} → {story_discovery} → {story_twist} → {story_result}

**STRUKTUR ARTIKEL (600-800 kata):**
1. **Intro** - {player_name} dari {city}, situasi awal
2. **Kejadian Tak Terduga** - Saat {story_action}
3. **Tentang **{game}**** - Features, bold game name
4. **Penemuan {player_name}** - {story_discovery}, dengan disclaimer
5. **Momen Kritis** - {story_twist}
6. **Hasil & Reaksi** - {story_result}, mention "hasil bervariasi"
7. **FAQ Section** (WAJIB - 4-5 pertanyaan)
8. **Kesimpulan** - Netral, edukatif

CRITICAL:
- Quote dari {player_name}: realistic & natural
- Mention {player_name} minimal 5x throughout artikel
- Bold game name: **{game}**
- Tone: netral, tidak over-hype

{base_guidelines}"""

        elif article_type == "generic_player":
            generic_term = data.get('generic_term', 'Pemain')
            city = data.get('city', 'Jakarta')
            location_prefix = data.get('location_prefix', 'asal')
            clickbait_angle = data.get('clickbait_angle', 'hebohkan warga')
            
            location = f"{location_prefix} {city}".strip()
            
            return f"""Buatkan artikel Google Discover OPTIMIZED dengan spesifikasi:

**ARTICLE TYPE:** Generic Player (tanpa profesi spesifik)

**DATA:**
- Term: {generic_term}
- Lokasi: {location}
- Game: {game}
- Platform: {platform}
- Kemenangan: {win_formatted}
- Angle: {clickbait_angle}

{story_context}

**TITLE FORMAT (60-80 kata, PLAIN TEXT, NO markdown):**
"{generic_term} {location} [action] **{game}** malah/saat [twist]"

**META DESCRIPTION (130-150 char, PLAIN TEXT):**
Seorang {generic_term} dari {location} mengalami kejadian tak terduga saat {story_situation}.

**STRUKTUR ARTIKEL (600-800 kata):**
1. **Intro** - {generic_term} dari {location}
2. **Kejadian** - {story_action} → {story_discovery}
3. **Tentang **{game}**** - Bold game name
4. **Twist** - {story_twist}
5. **Hasil** - {story_result}, dengan disclaimer
6. **FAQ Section** (WAJIB)
7. **Kesimpulan** - Netral

{base_guidelines}"""

        elif article_type == "multiple_players":
            player_count = data.get('player_count', 3)
            city = data.get('city', 'Jakarta')
            
            return f"""Buatkan artikel Google Discover OPTIMIZED dengan spesifikasi:

**ARTICLE TYPE:** Multiple Players

**DATA:**
- Jumlah Player: {player_count} orang
- Kota: {city}
- Game: {game}
- Platform: {platform}
- Total Kemenangan: {win_formatted}

{story_context}

**TITLE FORMAT (60-80 kata, PLAIN TEXT):**
"{player_count} Player {city} [action kolektif] **{game}** malah/saat [hasil]"

**META DESCRIPTION (130-150 char, PLAIN TEXT):**
Fenomena {player_count} pemain dari {city} yang mengalami kejadian serupa saat bermain.

**STRUKTUR ARTIKEL (600-800 kata):**
1. **Intro** - Fenomena {player_count} player
2. **Player Profiles** - Ringkas, masing-masing 1 paragraf
3. **Kesamaan Strategi** - Dengan disclaimer RNG
4. **FAQ Section** (WAJIB)
5. **Kesimpulan**

{base_guidelines}"""

        elif article_type == "listicle":
            tip_count = data.get('tip_count', 5)
            
            return f"""Buatkan artikel Google Discover FORMAT LISTICLE OPTIMIZED:

**ARTICLE TYPE:** Listicle (Numbered Tips)

**DATA:**
- Game: {game}
- Platform: {platform}
- Jumlah Tips: {tip_count}

{story_context}

**TITLE FORMAT (60-80 kata, PLAIN TEXT):**
"{tip_count} Trik **{game}** [detail] malah/yang [benefit]"

**META DESCRIPTION (130-150 char, PLAIN TEXT):**
Kumpulan {tip_count} trik bermain yang diklaim efektif, meski hasil dapat bervariasi.

**STRUKTUR (600-800 kata):**
1. **Intro** - Disclaimer: tips bukan jaminan
2. **Trik 1-{tip_count}** - Masing-masing 2-3 paragraf
3. **FAQ Section** (WAJIB)
4. **Kesimpulan** - Reminder tentang RNG

CRITICAL: Setiap trik mention "hasil bervariasi", "tergantung keberuntungan"

{base_guidelines}"""

        elif article_type == "transformational":
            profession = data.get('profession', 'Player')
            city = data.get('city', 'Jakarta')
            transformation = data.get('transformation', 'dari rugi jadi menang besar')
            starting_capital = data.get('starting_capital', None)
            
            modal_section = ""
            if starting_capital:
                modal_formatted = self._format_rupiah(starting_capital)
                modal_section = f"\n- Modal Awal: {modal_formatted}"
            
            return f"""Buatkan artikel Google Discover TRANSFORMATIONAL OPTIMIZED:

**ARTICLE TYPE:** Transformational (Before-After Story)

**DATA:**
- Profesi: {profession}
- Kota: {city}
- Game: {game}
- Platform: {platform}
- Transformasi: {transformation}
{modal_section}- Kemenangan: {win_formatted}

{story_context}

**TITLE FORMAT (60-80 kata, PLAIN TEXT):**
"{profession} {city} [kondisi before] **{game}** malah [transformasi]"

**META DESCRIPTION (130-150 char, PLAIN TEXT):**
Perjalanan seorang {profession} dari kondisi sulit hingga meraih hasil, meski belum terverifikasi.

**STRUKTUR (600-800 kata):**
1. **Intro** - Before condition
2. **Turning Point** - {story_action} → {story_discovery}
3. **Proses** - Dengan disclaimer
4. **Hasil** - {story_result}, mention "perlu verifikasi"
5. **FAQ Section** (WAJIB)
6. **Kesimpulan** - Edukatif, tidak over-promising

{base_guidelines}"""
        
        else:
            # Default fallback
            return f"""Buatkan artikel Google Discover OPTIMIZED tentang **{game}** di {platform} dengan kemenangan {win_formatted}.

{story_context}

{base_guidelines}"""
    
    def _build_story_context(self, action, discovery, twist, situation, accident, observation, result):
        """Build story context section dari story elements"""
        
        context_parts = []
        
        if action:
            context_parts.append(f"- Story Action: {action}")
        if discovery:
            context_parts.append(f"- Story Discovery: {discovery}")
        if twist:
            context_parts.append(f"- Story Twist: {twist}")
        if situation:
            context_parts.append(f"- Story Situation: {situation}")
        if accident:
            context_parts.append(f"- Story Accident: {accident}")
        if observation:
            context_parts.append(f"- Story Observation: {observation}")
        if result:
            context_parts.append(f"- Story Result: {result}")
        
        if context_parts:
            return "**STORY ELEMENTS (Gunakan untuk membuat cerita engaging):**\n" + "\n".join(context_parts)
        else:
            return ""
    
    def _create_fallback_result(self, article_type, data, win_formatted, content_text):
        """Create fallback result jika JSON parsing gagal"""
        
        game = data.get('game_name', 'Game')
        platform = data.get('platform_name', 'Platform')
        
        # Generate title based on type (PLAIN TEXT, NO MARKDOWN)
        if article_type == "single_player_name":
            name = data.get('player_name', 'Player')
            prof = data.get('profession', 'Pekerja')
            action = data.get('story_action', 'Coba Main')
            title = f"{name} {prof} {action} {game} Malah Langsung Jackpot"
        elif article_type == "single_player":
            prof = data.get('profession', 'Player')
            city = data.get('city', '')
            action = data.get('story_action', 'Main')
            title = f"{prof} {city} {action} {game} dan Raup Kemenangan"
        elif article_type == "listicle":
            count = data.get('tip_count', 5)
            title = f"{count} Trik {game} yang Diklaim Efektif"
        elif article_type == "multiple_players":
            count = data.get('player_count', 3)
            title = f"{count} Player Kompakan Main {game}"
        else:
            title = f"Kisah Unik dari {game}"
        
        # Clean title from markdown
        title = title.replace('#', '').replace('**', '').replace('*', '').strip()
        
        # Generate meta
        meta = content_text[:150] if len(content_text) > 150 else content_text
        meta = meta.replace('#', '').replace('**', '').replace('*', '').strip()
        
        return {
            "title": title[:80],
            "meta_description": meta[:150],
            "content": content_text
        }
    
    def _format_rupiah(self, amount):
        """Format angka ke format rupiah"""
        if isinstance(amount, str):
            amount = int(amount)
        
        if amount >= 1000000000:
            return f"Rp {amount/1000000000:.1f} Miliar"
        elif amount >= 1000000:
            return f"Rp {amount/1000000:.0f} Juta"
        elif amount >= 1000:
            return f"Rp {amount/1000:.0f} Ribu"
        else:
            return f"Rp {amount:,.0f}".replace(',', '.')
    
    def save_to_file(self, content_data, filename=None):
        """Simpan konten ke file JSON"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"article_{timestamp}.json"
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(content_data, f, ensure_ascii=False, indent=2)
        
        print(f"💾 Saved to: {filename}")
        return filename
    
    def batch_generate(self, articles_data):
        """Generate multiple articles sekaligus"""
        results = []
        
        for idx, data in enumerate(articles_data, 1):
            article_type = data.get('article_type', 'single_player')
            game = data.get('game_name', 'Game')
            
            print(f"\n[{idx}/{len(articles_data)}] Generating article...")
            print(f"   Type: {article_type}")
            print(f"   Game: {game}")
            
            try:
                # Generate content (pass all data via **kwargs)
                result = self.generate_content(**data)
                
                results.append({
                    "success": True,
                    "data": result,
                    "input": data
                })
                
                print(f"   ✅ Success: {result['title'][:50]}...")
                
            except Exception as e:
                results.append({
                    "success": False,
                    "error": str(e),
                    "input": data
                })
                
                print(f"   ❌ Failed: {str(e)}")
            
            # Rate limiting delay
            if idx < len(articles_data):
                import time
                time.sleep(2)
        
        return results


# ========== DEMO & TESTING ==========

if __name__ == "__main__":
    
    print("""
╔════════════════════════════════════════════════════════════════╗
║     GOOGLE DISCOVER GENERATOR V4.2                            ║
║     OPTIMIZED FOR GOOGLE DISCOVER                             ║
║     - NO hashtags/markdown in title & meta                    ║
║     - FAQ section mandatory                                   ║
║     - Neutral & educational tone                              ║
╚════════════════════════════════════════════════════════════════╝
    """)
    
    generator = GoogleDiscoverContentGenerator()
    
    # ===== DEMO: Single Player Name dengan Story Elements =====
    print("\n" + "="*60)
    print("DEMO: Generate Article (Google Discover Optimized)")
    print("="*60)
    
    sample_data = {
        "article_type": "single_player_name",
        "player_name": "Mawar",
        "profession": "Graphic Designer",
        "city": "Bandung",
        "game_name": "Mahjong Wins 3",
        "platform_name": "SLOT88",
        "win_amount": "85000000",
        "strategy_type": "pola scatter",
        "clickbait_angle": "Tak Disangka",
        "additional_context": "main sambil istirahat",
        # Story elements
        "story_action": "lihat monitor",
        "story_discovery": "lihat pola aneh",
        "story_twist": "bayangan gelap muncul",
        "story_situation": "lagi kerja malam",
        "story_accident": "monitor berkedip",
        "story_observation": "perhatiin layar",
        "story_result": "scatter melimpah"
    }
    
    try:
        print("\n⏳ Generating...")
        article = generator.generate_content(**sample_data)
        
        print(f"\n✅ Generated Successfully!")
        print(f"\n📄 TITLE (plain text, no markdown):")
        print(f"   {article['title']}")
        print(f"\n📝 META DESCRIPTION (plain text, no hashtag):")
        print(f"   {article['meta_description']}")
        print(f"\n📏 Content Length: ~{len(article['content'])} characters")
        
        # Check for FAQ
        if "FAQ" in article['content'] or "Pertanyaan" in article['content']:
            print(f"✅ FAQ Section: Found")
        else:
            print(f"⚠️  FAQ Section: Missing")
        
        # Check for markdown in title/meta
        if '#' in article['title'] or '#' in article['meta_description']:
            print(f"❌ WARNING: Hashtag found in title/meta!")
        else:
            print(f"✅ Clean: No hashtag in title/meta")
        
        generator.save_to_file(article, "demo_v42.json")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("⚠️  Make sure ANTHROPIC_API_KEY is set!")
    
    print("\n" + "="*60)
    print("✨ DEMO COMPLETED!")
    print("="*60)
    print("""
WHAT'S NEW IN V4.2:
✅ NO hashtags/markdown in title & meta (CRITICAL FIX)
✅ Shorter content: 600-800 words
✅ FAQ section mandatory (4-5 questions)
✅ Neutral & educational tone
✅ Bold keywords: **Game Name**, **RNG**
✅ Disclaimer about RNG & verification
✅ Focus on story, not winning amount
✅ Meta description max 150 chars

COMPATIBLE WITH:
✅ data_generator.py V4.1
✅ template_integrator.py V4.2 (akan diupdate)
✅ complete_workflow.py V4.1

NEXT: Update template_integrator.py untuk extra sanitization!
    """)