"""
AUTO DATA GENERATOR - VERSION 4.1 FIXED
========================================
MASSIVE DATABASE EXPANSION - 100-200+ items per category
FIXED: Indentation errors
"""

import random
import json

class ArticleDataGenerator:
    """Generate variasi data artikel dengan massive database"""
    
    def __init__(self):
        # ===== DATABASE NAMA (150+) =====
        self.names = [
            # Nama Umum Pria
            "Andi", "Budi", "Dani", "Eko", "Fajar", "Rangga", "Hadi", "Iqbal", "Joko", "Kemal",
            "Lukman", "Sigit", "Toni", "Wahyu", "Yanto", "Agus", "Bambang", "Dedi", "Firman",
            "Gatot", "Hendri", "Irfan", "Joni", "Krisna", "Lutfi", "Maman", "Nanda", "Oka",
            "Pandu", "Rudi", "Surya", "Teguh", "Udin", "Vito", "Wawan", "Yogi", "Zidan",
            
            # Nama Modern Pria
            "Kevin", "Ariel", "Dimas", "Reza", "Raffi", "Rizky", "Alvin", "Bryan", "David",
            "Eric", "Fikri", "Gilang", "Haris", "Ivan", "Jason", "Kenzo", "Leo", "Malik",
            "Nathan", "Oscar", "Rama", "Sandi", "Theo", "Vincent", "Zayn",
            
            # Nama Islam/Arab Pria
            "Muhammad", "Ahmad", "Hassan", "Umar", "Ali", "Yusuf", "Ibrahim", "Ismail",
            "Abdullah", "Khalid", "Zain", "Faisal", "Hakim", "Rizwan", "Syahrul",
            
            # Nama Umum Wanita
            "Ani", "Bella", "Citra", "Dewi", "Eka", "Fitri", "Gina", "Hana", "Ika", "Julia",
            "Kartika", "Lina", "Maya", "Nita", "Olivia", "Putri", "Rina", "Sari", "Tina", "Umi",
            "Vina", "Wulan", "Yuni", "Zahra", "Ayu", "Bunga", "Cika", "Diah", "Elsa", "Farah",
            
            # Nama Modern Wanita
            "Angel", "Cantika", "Diana", "Emily", "Felicia", "Grace", "Hannah", "Isabella",
            "Jessica", "Kimberly", "Laura", "Michelle", "Natasha", "Rachel", "Sophia",
            "Tiara", "Valerie", "Wendy", "Yolanda", "Zara",
            
            # Nama Daerah
            "Mawar", "Melati", "Sakura", "Kemuning", "Cempaka", "Anggrek", "Dahlia",
            "Bagus", "Cahyo", "Dwi", "Tri", "Widi", "Bayu", "Adi", "Putra", "Satria",
            
            # Nama Islam/Arab Wanita
            "Fatimah", "Aisyah", "Khadijah", "Maryam", "Zainab", "Safira", "Naura",
            "Aliya", "Salma", "Layla", "Amira", "Nadia", "Soraya", "Latifa"
        ]
        
        # ===== DATABASE PROFESI (100+) =====
        self.professions = [
            # Profesi Tradisional
            "Driver Ojol", "Tukang Bakso", "Montir Bengkel", "Tukang Cukur", "Teknisi HP",
            "Tukang Cuci Motor", "Tukang Parkir", "Penjaga Lahan Parkir", "Tukang Bangunan",
            "Tukang Las", "Tukang Kayu", "Tukang Cat", "Tukang Listrik", "Tukang Pipa",
            "Tukang Sablon", "Tukang Jahit", "Tukang Sepatu", "Tukang Kunci", "Tukang Jam",
            
            # Pedagang
            "Pedagang Keliling", "Penjual Nasi Goreng", "Penjual Sate", "Penjual Martabak",
            "Penjual Es Kelapa", "Penjual Gorengan", "Penjual Kopi", "Penjual Bubur",
            "Penjual Bakso", "Penjual Mie Ayam", "Penjual Nasi Uduk", "Penjual Cilok",
            "Pedagang Sayur", "Pedagang Buah", "Pedagang Ikan", "Pedagang Pakaian",
            
            # Transportasi
            "Sopir Angkot", "Sopir Bus", "Sopir Taksi", "Sopir Truck", "Sopir Pribadi",
            "Driver Grab", "Driver Gojek", "Driver Maxim", "Kurir JNE", "Kurir JNT",
            "Delivery Man", "Kurir Instan", "Tukang Ojek Pangkalan",
            
            # F&B
            "Chef Rumah Makan", "Koki Restoran", "Barista Kafe", "Pelayan Restoran",
            "Tukang Masak", "Baker", "Pastry Chef", "Juru Masak", "Cook Helper",
            
            # Retail & Service
            "Kasir Minimarket", "Kasir Supermarket", "SPG", "SPB", "Sales Toko",
            "Karyawan Toko", "Pramuniaga", "Sales Counter", "Teller Bank",
            "Customer Service", "Resepsionis Hotel", "Resepsionis Klinik",
            
            # Security & Cleaning
            "Security Mall", "Satpam Kantor", "Satpam Perumahan", "Penjaga Malam",
            "Cleaning Service", "Office Boy", "Tukang Kebun", "Penjaga Toko",
            
            # Pendidikan
            "Guru SD", "Guru SMP", "Guru SMA", "Guru TK", "Guru Les Privat",
            "Dosen", "Asisten Dosen", "Guru Ngaji", "Ustadz", "Tutor Online",
            
            # Kesehatan
            "Perawat RS", "Bidan", "Apoteker", "Asisten Apoteker", "Analis Lab",
            "Radiografer", "Petugas Farmasi", "Terapis",
            
            # IT & Digital
            "Programmer", "Web Developer", "Mobile Developer", "UI/UX Designer",
            "Graphic Designer", "Video Editor", "Content Creator", "Youtuber",
            "Blogger", "Influencer", "Admin Sosmed", "Digital Marketing",
            "SEO Specialist", "Data Entry", "IT Support",
            
            # Freelance & Modern
            "Freelancer", "Dropshipper", "Reseller Online", "Online Seller",
            "Fotografer", "Videografer", "Wedding Organizer", "MC", "DJ",
            "Makeup Artist", "Stylist", "Personal Trainer", "Instruktur Gym",
            
            # Lain-lain
            "Mahasiswa", "Ibu Rumah Tangga", "Pensiunan", "Wiraswasta",
            "Pengusaha Kecil", "Pemilik Warung", "Sales Motor", "Sales Mobil",
            "Marketing Property", "Agen Asuransi", "Calo Tiket", "Rental Mobil",
            "Pekerja Pabrik", "Buruh Harian", "Tukang Gali", "Petani", "Nelayan",
            "Peternak", "Supir Truk", "Kondektur", "Porter Stasiun"
        ]
        
        # ===== DATABASE KOTA (100+) =====
        self.cities = [
            # Kota Besar
            "Jakarta", "Bekasi", "Tangerang", "Depok", "Bogor", "Bandung", "Cirebon",
            "Sukabumi", "Tasikmalaya", "Banjar", "Semarang", "Solo", "Yogyakarta",
            "Magelang", "Surakarta", "Salatiga", "Pekalongan", "Tegal", "Purwokerto",
            "Cilacap", "Surabaya", "Malang", "Kediri", "Blitar", "Madiun", "Mojokerto",
            "Pasuruan", "Probolinggo", "Jember", "Banyuwangi", "Sidoarjo", "Gresik",
            
            # Sumatra
            "Medan", "Palembang", "Pekanbaru", "Padang", "Jambi", "Bengkulu",
            "Bandar Lampung", "Batam", "Tanjung Pinang", "Banda Aceh", "Lhokseumawe",
            "Langsa", "Pematang Siantar", "Binjai", "Tebing Tinggi", "Dumai",
            "Bukittinggi", "Payakumbuh", "Solok", "Lubuklinggau", "Pangkal Pinang",
            "Metro", "Kotabumi", "Pringsewu",
            
            # Kalimantan
            "Balikpapan", "Samarinda", "Banjarmasin", "Pontianak", "Palangkaraya",
            "Tarakan", "Bontang", "Singkawang", "Kuala Kapuas", "Sampit",
            
            # Sulawesi
            "Makassar", "Manado", "Palu", "Kendari", "Gorontalo", "Bitung", "Kotamobagu",
            "Tomohon", "Palopo", "Parepare", "Bau-Bau",
            
            # Bali & Nusa Tenggara
            "Denpasar", "Mataram", "Kupang", "Bima", "Sumbawa Besar", "Singaraja",
            
            # Papua & Maluku
            "Jayapura", "Sorong", "Manokwari", "Ambon", "Ternate", "Sofifi",
            
            # Kota Menengah & Kecil
            "Purwakarta", "Karawang", "Subang", "Indramayu", "Kuningan", "Ciamis",
            "Garut", "Cianjur", "Purbalingga", "Banjarnegara", "Wonosobo", "Kebumen"
        ]
        
        # ===== DATABASE PROVINSI (34) =====
        self.provinces = [
            "Aceh", "Sumatra Utara", "Sumatra Barat", "Riau", "Kepulauan Riau",
            "Jambi", "Sumatra Selatan", "Bangka Belitung", "Bengkulu", "Lampung",
            "Banten", "Jawa Barat", "DKI Jakarta", "Jawa Tengah", "DI Yogyakarta",
            "Jawa Timur", "Kalimantan Barat", "Kalimantan Tengah", "Kalimantan Selatan",
            "Kalimantan Timur", "Kalimantan Utara", "Sulawesi Utara", "Gorontalo",
            "Sulawesi Tengah", "Sulawesi Barat", "Sulawesi Selatan", "Sulawesi Tenggara",
            "Bali", "Nusa Tenggara Barat", "Nusa Tenggara Timur", "Maluku", "Maluku Utara",
            "Papua", "Papua Barat"
        ]
        
        # ===== DATABASE GAMES (80+) =====
        self.games = [
            # Pragmatic Play - Mahjong Series
            "Mahjong Ways", "Mahjong Ways 2", "Mahjong Wins", "Mahjong Wins 2",
            "Mahjong Panda", "Mahjong Wins Bonus Buy",
            
            # Pragmatic Play - Popular Slots
            "Gates of Olympus", "Gates of Olympus 1000", "Starlight Princess",
            "Starlight Princess 1000", "Sweet Bonanza", "Sweet Bonanza X1000",
            "Sweet Bonanza Xmas", "Sugar Rush", "Sugar Rush 1000",
            "Aztec Gems", "Aztec Bonanza", "Wild West Gold", "Wild West Gold Megaways",
            "The Dog House", "The Dog House Megaways", "Wolf Gold", "Mustang Gold",
            "Great Rhino", "Great Rhino Megaways", "Great Rhino Deluxe",
            
            # Pragmatic Play - Mythology Theme
            "Zeus vs Hades", "Zeus vs Hades Gods of War", "Power of Thor Megaways",
            "Hercules and Pegasus", "Treasures of Aztec", "Shield of Sparta",
            "Fire Strike", "Fire Strike 2", "Chilli Heat", "Buffalo King",
            
            # Pragmatic Play - Fruit Theme
            "Fruit Party", "Fruit Party 2", "Juicy Fruits", "Extra Juicy",
            "Extra Juicy Megaways", "Wild Beach Party",
            
            # Pragmatic Play - Other Popular
            "Bonanza Gold", "Gems Bonanza", "Big Bass Bonanza", "Bigger Bass Bonanza",
            "Cash Elevator", "Cash Bonanza", "Diamond Strike", "5 Lions Megaways",
            "Madame Destiny", "Madame Destiny Megaways", "Cowboys Gold",
            
            # PG Soft - Mahjong Series
            "Mahjong Ways 3", "Mahjong Wins 3", "Mahjong Wins 5",
            
            # PG Soft - Popular Games
            "Fortune Ox", "Fortune Tiger", "Fortune Mouse", "Fortune Rabbit",
            "Lucky Neko", "Prosperity Lion", "Ganesha Fortune", "Caishen Wins",
            "Legendary Monkey King", "Dragon Hatch", "Dragon Legend", "Phoenix Rises",
            "Garuda Gems", "Treasures of Aztec", "Wild Bounty Showdown",
            "Crypto Gold", "Emoji Riches", "Candy Bonanza", "Candy Burst",
            
            # PG Soft - Unique Themes
            "Ninja vs Samurai", "Muay Thai Champion", "Butterfly Blossom",
            "Double Fortune", "Tree of Fortune", "Plushie Frenzy", "Dreams of Macau",
            "Spirited Wonders", "Symbols of Egypt", "Opera Dynasty"
        ]
        
        # ===== DATABASE PLATFORMS (20+) =====
        self.platforms = [
            "WINSLOT118", "NAGABET76", "SLOT88", "SLOTVIP", "SLOTGACOR",
            "PRAGMATIC138", "SLOTDANA", "SLOT77", "SLOT5000", "RAJAGACOR",
            "SULTANGACOR", "KAISARGACOR", "MAXWIN138", "BONANZA88",
            "OLYMPUS88", "ZEUS138", "MAHJONG77", "SWEET88", "GACOR77",
            "HOKISLOT", "WINRATE88", "RTP88"
        ]
        
        # ===== DATABASE STRATEGIES (50+) =====
        self.strategies = [
            # Pola-based
            "pola scatter", "pola gacor", "pola malam", "pola siang", "pola pagi",
            "pola subuh", "pola petir", "pola naga", "pola phoenix", "pola zeus",
            "pola spin", "pola maxwin", "pola jackpot", "pola bonus",
            
            # Timing-based
            "waktu gacor", "timing tepat", "jam hoki", "waktu jackpot", "timing maxwin",
            "golden hour", "prime time slot", "waktu sepi", "jam ramai",
            
            # Strategy-based
            "strategi maxwin", "trik jitu", "teknik khusus", "metode ampuh",
            "cara curang", "rahasia admin", "bocoran RTP", "pola admin",
            
            # RTP & Data
            "RTP live", "RTP tinggi", "RTP 98%", "analisa RTP", "cek volatilitas",
            "mantau grafik", "lihat statistik", "pelajari data",
            
            # Bet Management
            "strategi bet kecil", "all in bet", "naik turun bet", "bet pattern",
            "martingale method", "flat betting", "progressive bet",
            
            # Advanced
            "algoritma mesin", "sistem random", "probability tinggi", "frekuensi scatter",
            "trigger bonus", "cycle detection"
        ]
        
        # ===== DATABASE ACTIONS (50+) =====
        self.actions = [
            # Browsing & Social Media
            "scrolling HP", "buka sosmed", "liat TikTok", "nonton YouTube", "baca artikel",
            "lihat iklan", "klik banner", "download aplikasi", "install game",
            "update aplikasi", "cek notifikasi",
            
            # Observasi
            "lihat HP orang", "perhatiin layar", "intip layar tetangga", "liat orang main",
            "ngelihatin", "kepo liat", "penasaran cek",
            
            # Social Interaction
            "dengar cerita temen", "dikasih tau", "diajarin", "ikut nonton",
            "ikut live streaming", "gabung grup", "diskusi sama temen",
            "ketemu player pro", "bertemu master",
            
            # Accident
            "salah pencet", "gak sengaja klik", "kebuka sendiri", "kepencet anak",
            "HP kejedot", "salah download", "salah klik iklan", "HP jatuh",
            
            # Casual Actions
            "iseng coba", "coba-coba", "test game", "pengen tau", "kepo cobain",
            "ikut-ikutan", "nyobain dulu", "ngetes pola",
            
            # Reading/Learning
            "baca tutorial", "nonton video tutorial", "belajar dari YouTube",
            "riset di Google", "cari info", "stalking grup"
        ]
        
        # ===== DATABASE DISCOVERIES (40+) =====
        self.discoveries = [
            # Finding Patterns
            "nemu strategi", "ketemu pola", "dapat trik", "bongkar rahasia",
            "temukan celah", "dapat bocoran", "ketahuan polanya", "nemu timing",
            
            # Learning
            "belajar teknik", "dapat ilmu", "ketemu cara", "nemu metode",
            "dapat insight", "paham sistemnya", "ngerti caranya",
            
            # Breakthrough
            "breakthrough momen", "eureka moment", "akhirnya paham", "terpecahkan",
            "dapat pencerahan", "ketemu kuncinya",
            
            # Pattern Recognition
            "kenal pola scatter", "hafal timing", "tau jam gacor", "deteksi cycle",
            "prediksi spin", "baca grafik", "analisa RTP",
            
            # Secret Discovery
            "bongkar algoritma", "crack sistem", "tembus firewall", "hack pola",
            "dapat cheat code", "unlock secret", "ketemu bug",
            
            # Tips & Tricks
            "dapat tips jitu", "ketemu trik ampuh", "nemu cara cepat",
            "dapat shortcut", "temukan cara mudah"
        ]
        
        # ===== DATABASE TWISTS (40+) =====
        self.twists = [
            # Visual Anomaly
            "layar berkedip", "bergerak aneh", "bayangan gelap", "cahaya muncul",
            "warna berubah", "gambar blur", "efek glitch", "screen freeze",
            
            # Scatter Phenomenon
            "scatter bertubi-tubi", "scatter nonstop", "scatter melimpah",
            "scatter muncul terus", "scatter beruntun", "scatter 10x berturut",
            
            # Winning Streak
            "maxwin tiba-tiba", "jackpot beruntun", "bonus berkali-kali",
            "win streak panjang", "kemenangan berturut", "profit nonstop",
            
            # Sound Effects
            "suara coin terus", "bunyi jackpot gak berhenti", "musik berubah",
            "notifikasi nonstop", "alarm berbunyi",
            
            # Number Anomaly
            "angka melompat", "multiplier gila", "RTP 100%", "volatilitas tinggi",
            "hit rate extreme", "frequency scatter naik",
            
            # Unexpected Events
            "HP panas", "baterai drop", "sinyal hilang", "aplikasi lag",
            "game freeze", "loading lama", "koneksi putus tapi tetap menang"
        ]
        
        # ===== DATABASE SITUATIONS (40+) =====
        self.situations = [
            # Waiting Time
            "lagi nunggu orderan", "nunggu antrian", "nunggu bus", "macet di jalan",
            "parkir lama", "waiting list", "ngantri makan",
            
            # Work Break
            "waktu istirahat", "break kerja", "jam makan siang", "istirahat sebentar",
            "coffee break", "jeda sejenak",
            
            # Daily Activities
            "sambil jualan", "lagi jaga toko", "jaga warung", "lagi kerja",
            "di bengkel", "di kantor", "di rumah", "di kos",
            
            # Time of Day
            "pagi-pagi", "siang bolong", "sore hari", "malam hari",
            "tengah malam", "jam 2 pagi", "subuh-subuh", "dini hari",
            
            # Mood & State
            "lagi bosan", "gabut", "sepi", "santai", "rileks", "stress",
            "capek kerja", "habis lembur",
            
            # Location-based
            "di toilet", "di kamar mandi", "di warteg", "di warung kopi",
            "di indomaret", "di SPBU", "di terminal", "di stasiun",
            
            # Before/After Events
            "sebelum tidur", "habis bangun", "setelah sholat", "habis makan",
            "mau berangkat kerja", "pulang kerja"
        ]
        
        # ===== DATABASE ACCIDENTS (30+) =====
        self.accidents = [
            # Mis-clicks
            "salah pencet", "salah klik", "salah tap", "miss click",
            "klik ganda gak sengaja", "double tap", "long press",
            
            # Phone Issues
            "HP nyala sendiri", "aplikasi kebuka sendiri", "screen kepencet",
            "HP kejedot", "HP jatuh", "layar retak tapi masih jalan",
            
            # External Factors
            "kepencet anak", "kucing nginjek HP", "kesenggol", "kepleset",
            "tertidur sambil pegang HP", "HP masuk kantong",
            
            # Download Errors
            "salah download", "salah install", "download game lain",
            "klik iklan salah", "redirect ke game",
            
            # Network
            "koneksi putus", "wifi mati", "kuota habis tapi masih nyambung",
            "lag parah", "ping tinggi tapi menang"
        ]
        
        # ===== DATABASE OBSERVATIONS (25+) =====
        self.observations = [
            "lihat pola aneh", "perhatiin layar", "amati gerakan", "cek statistik",
            "monitor RTP", "pantau scatter", "lihat grafik", "analisa data",
            "cek history", "teliti spin", "perhatikan timing", "lihat frekuensi",
            "amati cycle", "deteksi pattern", "observe behavior", "track result",
            "catat angka", "rekam layar", "screenshot hasil", "dokumentasi pola",
            "bandingkan data", "cross-check info", "verifikasi hasil",
            "lihat pergerakan", "perhatikan detail"
        ]
        
        # ===== DATABASE RESULTS (25+) =====
        self.results = [
            "langsung menang", "jackpot besar", "maxwin", "profit gede",
            "cuan melimpah", "untung besar", "kaya mendadak", "sultan dadakan",
            "scatter melimpah", "bonus terus", "win streak panjang",
            "kemenangan beruntun", "raih jutaan", "dapat ratusan juta",
            "modal balik 100x", "profit 1000%", "x1000 multiplier",
            "mega win", "super win", "ultra win", "epic win",
            "withdraw gede", "saldo meledak", "balance melonjak"
        ]
        
        # ===== OTHER DATABASES =====
        self.article_types = [
            "single_player",
            "single_player_name",
            "generic_player",
            "multiple_players",
            "listicle",
            "transformational"
        ]
        
        self.generic_terms = [
            "Pemain", "Pria", "Wanita", "Member", "Player", "Warga", "Orang"
        ]
        
        self.location_prefixes = ["asal", "pinggiran kota", ""]
        
        self.transformations = [
            "dari sering rugi jadi menang besar",
            "dari bangkrut jadi kaya raya",
            "langsung jadi bos",
            "jadi sultan dadakan",
            "berubah nasib 180 derajat",
            "langsung kaya mendadak",
            "dari minus jadi surplus",
            "hutang lunas dalam sehari"
        ]
        
        self.clickbait_angles = [
            "tak disangka", "hebohkan warga", "bikin penonton terkejut",
            "gegerkan kampung", "viral di sosmed", "trending topic",
            "bikin iri tetangga", "mengejutkan banyak orang"
        ]
        
        self.contexts = [
            "main sambil rebahan", "bermodal recehan", "modal receh",
            "main di waktu istirahat", "coba-coba iseng",
            "langsung pecah maxwin", "auto jackpot"
        ]
        
        self.win_amounts = [
            18000000, 35000000, 55000000, 67000000, 85000000,
            95000000, 105000000, 120000000, 150000000, 175000000,
            200000000, 259000000, 300000000, 500000000, 750000000,
            918000000, 1000000000
        ]
        
        self.starting_capitals = [
            25000, 35000, 50000, 75000, 100000, 150000, 200000
        ]
    
    def generate_single(self, article_type=None):
        """Generate 1 data artikel dengan massive database"""
        
        if article_type is None:
            article_type = random.choice(self.article_types)
        
        data = {
            "article_type": article_type,
            "game_name": random.choice(self.games),
            "platform_name": random.choice(self.platforms),
            "win_amount": str(random.choice(self.win_amounts)),
            "strategy_type": random.choice(self.strategies)
        }
        
        # Add storytelling elements
        data["story_action"] = random.choice(self.actions)
        data["story_discovery"] = random.choice(self.discoveries)
        data["story_twist"] = random.choice(self.twists)
        data["story_situation"] = random.choice(self.situations)
        data["story_accident"] = random.choice(self.accidents)
        data["story_observation"] = random.choice(self.observations)
        data["story_result"] = random.choice(self.results)
        
        # Type-specific data (FIXED INDENTATION)
        if article_type == "single_player":
            data["profession"] = random.choice(self.professions)
            data["city"] = random.choice(self.cities)
            data["location_prefix"] = random.choice(self.location_prefixes)
            data["clickbait_angle"] = random.choice(self.clickbait_angles)
            data["additional_context"] = random.choice(self.contexts)
            
        elif article_type == "single_player_name":
            data["player_name"] = random.choice(self.names)
            data["profession"] = random.choice(self.professions)
            data["city"] = random.choice(self.cities)
            data["clickbait_angle"] = random.choice(self.clickbait_angles)
            data["additional_context"] = random.choice(self.contexts)
            
        elif article_type == "generic_player":
            data["generic_term"] = random.choice(self.generic_terms)
            if random.random() > 0.5:
                data["city"] = random.choice(self.cities)
            else:
                data["city"] = random.choice(self.provinces)
            data["location_prefix"] = random.choice(["asal", ""])
            data["clickbait_angle"] = random.choice(self.clickbait_angles)
            
        elif article_type == "multiple_players":
            data["player_count"] = random.randint(3, 6)
            data["city"] = random.choice(self.cities)
            data["clickbait_angle"] = random.choice(["berhasil jackpot besar", "raih kemenangan fantastis"])
            
        elif article_type == "listicle":
            data["tip_count"] = random.randint(5, 10)
            data["listicle_title"] = f"{data['tip_count']} Trik Jitu"
            data["clickbait_angle"] = "langsung pecah maxwin"
            
        elif article_type == "transformational":
            data["profession"] = random.choice(self.professions)
            data["city"] = random.choice(self.cities)
            data["transformation"] = random.choice(self.transformations)
            if random.random() > 0.5:
                data["starting_capital"] = str(random.choice(self.starting_capitals))
        
        return data
    
    def generate_batch(self, count=10, article_type=None):
        """Generate multiple articles"""
        articles = []
        for _ in range(count):
            articles.append(self.generate_single(article_type))
        return articles
    
    def generate_mixed_batch(self, count=15):
        """Generate batch dengan mix berbagai types"""
        articles = []
        
        type_distribution = (
            ["single_player"] * 5 +
            ["single_player_name"] * 3 +
            ["generic_player"] * 3 +
            ["multiple_players"] * 2 +
            ["listicle"] * 1 +
            ["transformational"] * 1
        )
        
        random.shuffle(type_distribution)
        
        for article_type in type_distribution[:count]:
            articles.append(self.generate_single(article_type))
        
        return articles
    
    def save_to_json(self, articles, filename="articles_data.json"):
        """Save to JSON"""
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(articles, f, ensure_ascii=False, indent=2)
        print(f"✅ Saved {len(articles)} articles to {filename}")
        return filename
    
    def preview_titles(self, articles):
        """Preview article titles"""
        print("\n📰 PREVIEW TITLES:\n")
        for idx, article in enumerate(articles, 1):
            title = self._generate_title_preview(article)
            print(f"{idx}. {title}")
    
    def _generate_title_preview(self, article):
        """Generate preview title based on article data"""
        atype = article['article_type']
        game = article['game_name']
        win = int(article['win_amount']) // 1000000
        
        if atype == "single_player":
            prof = article['profession']
            city = article['city']
            prefix = article.get('location_prefix', '')
            loc = f"{prefix} {city}".strip() if prefix else city
            angle = article.get('clickbait_angle', '')
            return f"{angle} {prof} {loc} raup Rp {win} juta dari {game}"
            
        elif atype == "single_player_name":
            name = article['player_name']
            prof = article['profession']
            strategy = article['strategy_type']
            return f"{name} {prof} akui {strategy} bawa kemenangan {win}jt di {game}"
            
        elif atype == "generic_player":
            term = article['generic_term']
            city = article['city']
            prefix = article.get('location_prefix', '')
            loc = f"{prefix} {city}".strip() if prefix else city
            return f"{term} {loc} hebohkan warga kantongi {win}jt dari {game}"
            
        elif atype == "multiple_players":
            count = article['player_count']
            return f"{count} player berhasil jackpot besar {game} raih total Rp {win * count} juta"
            
        elif atype == "listicle":
            tips = article['tip_count']
            return f"{tips} trik jitu {game} langsung pecah maxwin dalam sekejap"
            
        elif atype == "transformational":
            prof = article['profession']
            trans = article['transformation']
            return f"{prof} {trans} dari {game} raup Rp {win} juta"
        
        return "Sample Title"
    
    def print_statistics(self, articles):
        """Print database statistics"""
        print("\n" + "="*70)
        print("📊 DATABASE STATISTICS")
        print("="*70)
        print(f"Total Nama: {len(self.names)}")
        print(f"Total Profesi: {len(self.professions)}")
        print(f"Total Kota: {len(self.cities)}")
        print(f"Total Provinsi: {len(self.provinces)}")
        print(f"Total Games: {len(self.games)}")
        print(f"Total Platforms: {len(self.platforms)}")
        print(f"Total Strategies: {len(self.strategies)}")
        print(f"Total Actions: {len(self.actions)}")
        print(f"Total Discoveries: {len(self.discoveries)}")
        print(f"Total Twists: {len(self.twists)}")
        print(f"Total Situations: {len(self.situations)}")
        print(f"Total Accidents: {len(self.accidents)}")
        print(f"Total Observations: {len(self.observations)}")
        print(f"Total Results: {len(self.results)}")
        
        types_count = {}
        for article in articles:
            atype = article['article_type']
            types_count[atype] = types_count.get(atype, 0) + 1
        
        print("\n📈 ARTICLE TYPES DISTRIBUTION:")
        for atype, count in types_count.items():
            print(f"   - {atype}: {count}")


# DEMO
if __name__ == "__main__":
    
    print("""
╔══════════════════════════════════════════════════════════════════════╗
║     AUTO DATA GENERATOR V4.1 - MASSIVE DATABASE EXPANSION          ║
║     150+ Nama | 100+ Profesi | 100+ Kota | 80+ Games              ║
╚══════════════════════════════════════════════════════════════════════╝
    """)
    
    generator = ArticleDataGenerator()
    
    print("\n" + "="*70)
    print("DEMO 1: Generate 15 Artikel Mixed Types")
    print("="*70)
    
    articles_mixed = generator.generate_mixed_batch(15)
    generator.preview_titles(articles_mixed)
    generator.save_to_json(articles_mixed, "articles_mixed_15.json")
    
    print("\n" + "="*70)
    print("DEMO 2: Generate 100 Artikel Production")
    print("="*70)
    
    articles_100 = generator.generate_mixed_batch(100)
    generator.save_to_json(articles_100, "articles_production_100.json")
    
    print(f"\n✅ Generated {len(articles_100)} artikel!")
    print("📁 Saved to: articles_production_100.json")
    
    print("\n📰 Preview 10 artikel pertama:")
    generator.preview_titles(articles_100[:10])
    
    # Print statistics
    generator.print_statistics(articles_100)
    
    print("\n" + "="*70)
    print("DEMO 3: Sample Data dengan Story Elements")
    print("="*70)
    
    sample = generator.generate_single("single_player_name")
    print("\n🎯 SAMPLE GENERATED DATA:")
    for key, value in sample.items():
        print(f"   {key}: {value}")
    
    print("\n" + "="*70)
    print("✨ SELESAI!")
    print("="*70)
    print("\n💡 TIPS:")
    print("   - Gunakan generate_mixed_batch() untuk variasi")
    print("   - Gunakan generate_batch(count, 'type') untuk spesifik type")
    print("   - Semua data sudah include story elements")
    print("   - Database massive: 150+ nama, 100+ profesi, 100+ kota!")
            